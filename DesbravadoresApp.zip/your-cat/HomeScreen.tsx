import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  SafeAreaView, 
  StatusBar,
  Pressable 
} from 'react-native';

export default function HomeScreen({ navigation }) {
  const [menuVisible, setMenuVisible] = useState(false);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      {/* --- HEADER (Login e Três Pontos) --- */}
      <View style={styles.header}>
        <View style={styles.headerRight}> 
          <TouchableOpacity 
            style={styles.loginSmallBtn}
            onPress={() => navigation.navigate('Login')}
          >
            <Text style={styles.loginText}>Login</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.pontosBtn} 
            onPress={() => setMenuVisible(!menuVisible)}
          >
            <Text style={styles.dotsText}>⋮</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* --- MENU DROPDOWN (Aparece ao clicar nos pontos) --- */}
      {menuVisible && (
        <>
          {/* Camada invisível para fechar o menu ao clicar fora */}
          <Pressable 
            style={styles.menuOverlay} 
            onPress={() => setMenuVisible(false)} 
          />
          <View style={styles.dropdownMenu}>
            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => { setMenuVisible(false); navigation.navigate('Perfil'); }}
            >
              <Text style={styles.menuItemText}>👤 Perfil</Text>
            </TouchableOpacity>
            
            <View style={styles.menuDivider} />
            
            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => { setMenuVisible(false); navigation.navigate('Login'); }}
            >
              <Text style={[styles.menuItemText, { color: '#EF4444' }]}>🚪 Sair</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      {/* --- CONTEÚDO CENTRAL --- */}
      <View style={styles.mainContent}>
        <Text style={styles.welcomeText}>Sua Dashboard</Text>
        <Text style={styles.infoText}>Conteúdo principal do seu app aqui.</Text>
      </View>

      {/* --- BARRA INFERIOR --- */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.navIcon}>🏠</Text>
          <Text style={styles.navTextActive}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Progresso')}>
          <Text style={styles.navIcon}>📈</Text>
          <Text style={styles.navText}>Progresso</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
    justifyContent: 'space-between',
  },
  header: {
    height: 60,
    flexDirection: 'row',
    justifyContent: 'flex-end', // Alinha tudo para a direita
    alignItems: 'center',
    paddingHorizontal: 20,
    zIndex: 10, // Garante que o menu fique por cima
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginSmallBtn: {
    backgroundColor: '#6366F1',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginRight: 10,
  },
  loginText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 14,
  },
  pontosBtn: {
    padding: 5,
  },
  dotsText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#374151',
  },
  /* Dropdown Styles */
  menuOverlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 5,
  },
  dropdownMenu: {
    position: 'absolute',
    top: 60,
    right: 20,
    backgroundColor: '#FFF',
    width: 150,
    borderRadius: 12,
    padding: 10,
    zIndex: 20,
    // Sombra
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  menuItem: {
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  menuItemText: {
    fontSize: 15,
    color: '#374151',
    fontWeight: '500',
  },
  menuDivider: {
    height: 1,
    backgroundColor: '#F3F4F6',
  },
  /* Resto dos estilos */
  mainContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  welcomeText: { fontSize: 22, fontWeight: 'bold' },
  infoText: { color: '#6B7280', marginTop: 10 },
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    height: 80,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    paddingBottom: 20,
  },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navIcon: { fontSize: 20 },
  navText: { fontSize: 12, color: '#6B7280' },
  navTextActive: { fontSize: 12, color: '#6366F1', fontWeight: 'bold' },
});