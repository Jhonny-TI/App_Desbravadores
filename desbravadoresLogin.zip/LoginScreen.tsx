import React, { useState } from 'react';
import { Text, View, TextInput, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [tipoUsuario, setTipoUsuario] = useState('aluno');

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.logoContainer}>
          <Image source={require('./assets/img/icone.jpeg')} style={styles.logo} />
        </View>

        <Text style={styles.titulo}>Bem-vindo</Text>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={styles.input}
          placeholder="Senha"
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />

        <View style={styles.tipoContainer}>
          <TouchableOpacity 
            style={[styles.tipoBotao, tipoUsuario === 'aluno' && styles.tipoSelecionado]}
            onPress={() => setTipoUsuario('aluno')}
          >
            <Text style={tipoUsuario === 'aluno' ? styles.tipoTextoSelecionado : styles.tipoTexto}>Aluno</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.tipoBotao, tipoUsuario === 'professor' && styles.tipoSelecionado]}
            onPress={() => setTipoUsuario('professor')}
          >
            <Text style={tipoUsuario === 'professor' ? styles.tipoTextoSelecionado : styles.tipoTexto}>Professor</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.botao} onPress={() => console.log('Login', email)}>
          <Text style={styles.textoBotao}>Entrar</Text>
        </TouchableOpacity>

        <View style={styles.extraContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('RecuperarEmail')}>
            <Text style={styles.link}>Recuperar senha</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('CriarConta')}>
            <Text style={styles.link}>Criar conta</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f4f7', justifyContent: 'center', padding: 20 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 20, elevation: 5 },
  logoContainer: { alignSelf: 'center', marginBottom: 10 },
  logo: { width: 90, height: 90, borderRadius: 45 },
  titulo: { fontSize: 26, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  input: { backgroundColor: '#fafafa', padding: 14, borderRadius: 12, marginBottom: 15, borderWidth: 1, borderColor: '#ddd' },
  tipoContainer: { flexDirection: 'row', marginBottom: 15 },
  tipoBotao: { flex: 1, padding: 12, borderRadius: 10, backgroundColor: '#e0e0e0', marginHorizontal: 5 },
  tipoSelecionado: { backgroundColor: '#007bff' },
  tipoTexto: { textAlign: 'center', fontWeight: 'bold' },
  tipoTextoSelecionado: { color: '#fff', textAlign: 'center', fontWeight: 'bold' },
  botao: { backgroundColor: '#007bff', padding: 15, borderRadius: 12, alignItems: 'center' },
  textoBotao: { color: '#fff', fontWeight: 'bold' },
  extraContainer: { marginTop: 15, alignItems: 'center' },
  link: { color: '#007bff', marginTop: 10 }
});