import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TouchableOpacity, 
  SafeAreaView, 
  StatusBar,
  Pressable,
  Image,
  FlatList, // Importado
  Dimensions, // Importado para saber a largura da tela
  
} from 'react-native';

const { width } = Dimensions.get('window');

// Dados fictícios para o carrossel
const CAROUSEL_DATA = [
  { id: '1', image: require('./assets/cards/classeAmigo.png') },
  { id: '2', image: require('./assets/cards/classeCompanheiro.png') },
  { id: '3', image: require('./assets/cards/classePesquisador.png') },
  { id: '4', image: require('./assets/cards/classePioneiro.png') },
  { id: '5', image: require('./assets/cards/classeExcursionista.png') },
  { id: '6', image: require('./assets/cards/classeGuia.png') },
  //800 x 400 pixels o tamanho das images a serem feitas

];

export default function HomeScreen({ navigation }) {
  const [menuVisible, setMenuVisible] = useState(false);

  // Função que renderiza cada item do carrossel
  const renderBanner = ({ item }) => (
  <View style={styles.card}>
    <Image 
      source={typeof item.image === 'string' ? { uri: item.image } : item.image} 
      style={styles.fullImage} 
    />
  </View>
);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      {/* --- HEADER --- */}
<View style={styles.header}>
  <View style={styles.headerLeft}>
    {/* Adicionado o estilo diretamente na imagem */}
    <Image 
      source={require('./assets/icones/desbravIcone.png')} 
      style={styles.logoTopo} 
      resizeMode="contain"
    />
  </View>

  <View style={styles.headerRight}> 
    <TouchableOpacity style={styles.loginSmallBtn} onPress={() => navigation.navigate('Login')}>
      <Text style={styles.loginText}>Login</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.pontosBtn} onPress={() => setMenuVisible(!menuVisible)}>
        <Image source={require('./assets/icones/dots.png')} style={styles.imagemPontos} resizeMode="contain" />       
    </TouchableOpacity>
  </View>
</View>

      {/* --- MENU DROPDOWN --- */}
      {menuVisible && (
        <>
          <Pressable style={styles.menuOverlay} onPress={() => setMenuVisible(false)} />
          <View style={styles.dropdownMenu}>
            <TouchableOpacity style={styles.menuItem} onPress={() => setMenuVisible(false)}>
                <Image source={require('./assets/icones/user.png')} style={styles.imagemUser} />
                <Text style={styles.menuItemText}>Perfil</Text>
            </TouchableOpacity>
            <View style={styles.menuDivider} />
            <TouchableOpacity style={styles.menuItem} onPress={() => setMenuVisible(false)}>
                <Image source={require('./assets/icones/exit.png')} style={styles.imagemExit} />
                <Text style={styles.menuItemText}>Sair</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      {/* --- CONTEÚDO CENTRAL COM CARROSSEL --- */}
      <View style={styles.mainContent}>
        <View style={styles.welcomeContainer}>
          <Text style={styles.welcomeText}>Mural do Desbravador</Text>
          <Text style={styles.infoText}>Onde a Aventura Começa !</Text>
        </View>

        {/* Implementação do Carrossel */}
        <View style={styles.carouselWrapper}>
          <FlatList
            data={CAROUSEL_DATA}
            renderItem={renderBanner}
            keyExtractor={(item) => item.id}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            snapToAlignment="center"
            decelerationRate="fast"
          />
        </View>
        
        <View style={styles.placeholderContent}>
            <Image source={require('./assets/desbravImage.png')} style={styles.desbravImage}/>
        </View>
      </View>

      {/* --- BARRA INFERIOR --- */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Home')}>
          <Image source={require('./assets/icones/home.png')} style={styles.imagemHome} />
          <Text style={styles.navTextActive}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Progresso')}>
          <Image source={require('./assets/icones/progress.png')} style={styles.imagemProgress} />
          <Text style={styles.navText}>Progresso</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9FAFB' },
  header: { 
    height: 60, 
    flexDirection: 'row', 
    justifyContent: 'space-between', // Altera de flex-end para space-between
    alignItems: 'center', 
    paddingHorizontal: 20, 
    zIndex: 10 
  },
  headerLeft: {
    flex: 1, // Faz o lado esquerdo ocupar o espaço disponível
    justifyContent: 'center',
    alignItems: 'flex-start', // Garante que fique na esquerda
  },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  loginSmallBtn: { backgroundColor: '#6366F1', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 8, marginRight: 10 },
  loginText: { color: '#FFF', fontWeight: '600', fontSize: 14 },
  pontosBtn: { padding: 8, width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  imagemPontos: { width: '100%', height: '100%' },
logoTopo: {
    width: 45,  
    height: 45,
  },
  /* Menu Dropdown */
  menuOverlay: { ...StyleSheet.absoluteFillObject, zIndex: 5 },
  dropdownMenu: { position: 'absolute', top: 60, right: 20, backgroundColor: '#FFF', width: 150, borderRadius: 12, padding: 10, zIndex: 20, elevation: 5, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 8 },
  menuItem: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 10, alignItems: 'center' },
  menuItemText: { fontSize: 15, color: '#374151', fontWeight: '500' },
  menuDivider: { height: 1, backgroundColor: '#F3F4F6' },
  imagemUser: { width: 15, height: 15, marginRight: 10, resizeMode: 'contain' },
  imagemExit: { width: 15, height: 15, marginRight: 10, resizeMode: 'contain' },


  /* Conteúdo Central e Carrossel */
  mainContent: { flex: 1, paddingTop: 20 },
  welcomeContainer: { paddingHorizontal: 20, marginBottom: 20 },
  welcomeText: { fontSize: 22, fontWeight: 'bold' },
  infoText: { color: '#6B7280', marginTop: 4 },
  
  carouselWrapper: { height: 180 }, // Altura do carrossel
  card: {
    width: width - 40, // Mantém a margem nas laterais
    height: 180,       // Altura fixa para o banner
    marginHorizontal: 20,
    borderRadius: 15,
    overflow: 'hidden', // Importante para a imagem não "vazar" da borda arredondada
    backgroundColor: '#EEE', // Uma cor de fundo caso a imagem demore a carregar
  },
  fullImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover', // Faz a imagem preencher o espaço todo
  },

desbravImage: {
    width: 400,
    height: 200,
    resizeMode: 'contain'
  },
  
  placeholderContent: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  /* Barra Inferior */
  bottomNav: { flexDirection: 'row', backgroundColor: '#FFF', height: 80, borderTopWidth: 1, borderTopColor: '#F3F4F6', paddingBottom: 20 },
  imagemHome: { width: 25, height: 25, marginBottom: 4, resizeMode: 'contain' },
  imagemProgress: { width: 25, height: 25, marginBottom: 4, resizeMode: 'contain' },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navText: { fontSize: 12, color: '#6B7280' },
  navTextActive: { fontSize: 12, color: 'black', fontWeight: 'bold' },
});