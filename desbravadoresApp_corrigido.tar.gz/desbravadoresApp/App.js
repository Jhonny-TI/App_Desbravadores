import React from 'react';
import 'react-native-gesture-handler';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './screens/HomeScreen';
import LoginScreen from './screens/LoginScreen';
import CriarContaScreen from './screens/CriarConta';
import RequisitoScreen from './screens/RequisitoScreen';
import RecuperarEmailScreen from './screens/RecuperarEmail';
import RedefinirSenhaScreen from './screens/RedefinirSenhaScreen';
import ProfileScreen from './screens/ProfileScreen';
import TermosScreen from './screens/TermosScreen';
import ConsentimentoScreen from './screens/ConsentimentoScreen';
import PrimeiroAcessoScreen from './screens/PrimeiroAcessoScreen';
import PainelProfessorScreen from './screens/PainelProfessorScreen';
import FichaAlunoScreen from './screens/FichaAlunoScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    // GestureHandlerRootView + SafeAreaProvider são os "wrappers" que fazem
    // gestos e áreas seguras (notch/status bar) funcionarem corretamente.
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {/* Pública */}
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="CriarConta" component={CriarContaScreen} />
            <Stack.Screen name="Requisito" component={RequisitoScreen} />
            <Stack.Screen name="RecuperarEmail" component={RecuperarEmailScreen} />
            <Stack.Screen name="RedefinirSenha" component={RedefinirSenhaScreen} />
            <Stack.Screen name="Termos" component={TermosScreen} />
            <Stack.Screen name="Consentimento" component={ConsentimentoScreen} />
            {/* Primeiro acesso (professor/ADM) */}
            <Stack.Screen name="PrimeiroAcesso" component={PrimeiroAcessoScreen} />
            {/* Logado - aluno */}
            <Stack.Screen name="Perfil" component={ProfileScreen} />
            {/* Logado - professor */}
            <Stack.Screen name="PainelProfessor" component={PainelProfessorScreen} />
            <Stack.Screen name="FichaAluno" component={FichaAlunoScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
