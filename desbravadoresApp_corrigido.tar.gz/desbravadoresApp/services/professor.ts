// =============================================
// SERVIÇO DO PROFESSOR
// =============================================
// Lista/busca alunos, abre a ficha de um aluno e avança/retrocede a classe.

import { apiGet, apiPost } from './api';

export type AlunoResumo = {
  id: number;
  nome: string;
  email: string;
  classe: string;
  ativo: boolean;
  concluidas: number;
};

// Lista alunos, com busca opcional por nome ou email.
export async function listarAlunos(busca = ''): Promise<AlunoResumo[]> {
  const q = busca ? `?busca=${encodeURIComponent(busca)}` : '';
  const data = await apiGet(`/professor/listar_alunos.php${q}`);
  return data.alunos || [];
}

// Ficha completa de um aluno.
export async function fichaAluno(id: number): Promise<any> {
  return apiGet(`/professor/ficha_aluno.php?id=${id}`);
}

// Requisitos que o aluno marcou numa classe (com fotos), p/ o professor verificar.
export async function requisitosAluno(id: number, classe: string): Promise<{ [indice: string]: { foto: string | null; marcadoEm: string } }> {
  const data = await apiGet(`/professor/requisitos_aluno.php?id=${id}&classe=${encodeURIComponent(classe)}`);
  return data.marcados || {};
}

// Avança o aluno para a próxima classe (conclui a atual).
export async function avancarClasse(alunoId: number): Promise<any> {
  return apiPost('/professor/avancar_classe.php', { alunoId });
}

// Desfaz: volta o aluno para a classe anterior.
export async function retrocederClasse(alunoId: number): Promise<any> {
  return apiPost('/professor/retroceder_classe.php', { alunoId });
}
