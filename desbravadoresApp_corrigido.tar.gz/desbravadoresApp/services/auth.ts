// =============================================
// SERVIÇO DE AUTENTICAÇÃO
// =============================================
// Liga as telas de login/cadastro/recuperação ao backend PHP,
// e mantém o usuário logado guardado no dispositivo (getUser/setUser/logout)
// — que é o que HomeScreen, useAuth, etc. já consomem.

import AsyncStorage from '@react-native-async-storage/async-storage';
import { apiPost, setToken, clearToken } from './api';

const USER_KEY = '@app:user';

export type User = {
  id?: number;
  nome: string;
  email: string;
  tipo: 'aluno' | 'professor';
  classe?: string;
  dataNascimento?: string | null;
  idade?: number | null;
  fotoUrl?: string | null;
  senhaProvisoria?: boolean;
  termosAceitos?: boolean;
};

// ---- Estado local do usuário (sem rede) ----
export async function getUser(): Promise<User | null> {
  try {
    const raw = await AsyncStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as User) : null;
  } catch {
    return null;
  }
}
export async function setUser(user: User): Promise<void> {
  await AsyncStorage.setItem(USER_KEY, JSON.stringify(user));
}

// ---- Chamadas ao backend ----

// Faz login no servidor, salva token + usuário, devolve o usuário.
export async function login(email: string, senha: string): Promise<User> {
  const data = await apiPost('/auth/login.php', { email, senha });
  await setToken(data.token);
  await setUser(data.usuario);
  return data.usuario;
}

// Cadastra aluno. Retorna { usuario, reativada }.
export async function cadastrar(
  nome: string,
  email: string,
  senha: string,
  termosAceitos: boolean,
  dataNascimento: string // formato YYYY-MM-DD ('' se não informado)
): Promise<{ usuario: User; reativada: boolean }> {
  const data = await apiPost('/auth/cadastrar.php', {
    nome,
    email,
    senha,
    termosAceitos,
    dataNascimento,
  });
  await setToken(data.token);
  await setUser(data.usuario);
  return { usuario: data.usuario, reativada: !!data.reativada };
}

// Pede email de redefinição de senha.
export async function recuperarSenha(email: string): Promise<string> {
  const data = await apiPost('/auth/enviar_email_redefinir_senha.php', { email });
  return data.message;
}

// Define nova senha a partir do token recebido por email.
export async function atualizarSenha(token: string, novaSenha: string): Promise<string> {
  const data = await apiPost('/auth/atualizar_senha.php', { token, novaSenha });
  return data.message;
}

// Logout: encerra a sessão no servidor e limpa o estado local.
export async function logout(): Promise<void> {
  try {
    await apiPost('/auth/logout.php', {});
  } catch {
    // mesmo que o servidor falhe, limpamos localmente
  }
  await clearToken();
  await AsyncStorage.removeItem(USER_KEY);
}
