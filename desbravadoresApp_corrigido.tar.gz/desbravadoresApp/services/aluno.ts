// =============================================
// SERVIÇO DO ALUNO
// =============================================
// Requisitos marcados, fotos de evidência, perfil e exclusão de conta.
// Todas as funções usam o cliente HTTP central (api.ts).

import { apiGet, apiPost, apiPut, apiDelete, apiUpload } from './api';

export type RequisitosMarcados = {
  // chave = índice do requisito; valor = { foto: url|null }
  [indice: string]: { foto: string | null };
};

// Lista os requisitos marcados de uma classe pelo aluno logado.
export async function listarRequisitos(classe: string): Promise<RequisitosMarcados> {
  const data = await apiGet(`/aluno/requisitos.php?classe=${encodeURIComponent(classe)}`);
  return data.marcados || {};
}

// Marca ou desmarca um requisito (sem foto).
export async function marcarRequisito(
  classe: string,
  indice: number,
  marcado: boolean
): Promise<void> {
  await apiPost('/aluno/marcar_requisito.php', { classe, indice, marcado });
}

// Envia uma foto de evidência (marca o requisito automaticamente).
// Retorna a URL pública da foto salva no servidor.
export async function enviarFoto(
  classe: string,
  indice: number,
  fileUri: string
): Promise<string> {
  const data = await apiUpload(
    '/aluno/upload_foto.php',
    { classe, indice: String(indice) },
    fileUri
  );
  return data.fotoUrl;
}

// Remove SÓ a foto (lixeira) — mantém o requisito marcado.
export async function removerFoto(classe: string, indice: number): Promise<void> {
  await apiPost('/aluno/remover_foto.php', { classe, indice });
}

// ---- Perfil ----
export async function getPerfil(): Promise<any> {
  return apiGet('/aluno/perfil.php');
}

export async function atualizarPerfil(campos: {
  nome?: string;
  email?: string;
  senha?: string;
  senhaAtual?: string;
  fotoUrl?: string;
}): Promise<any> {
  // A classe ativa NÃO é editável pelo aluno (só professor avança classe).
  return apiPut('/aluno/perfil.php', campos);
}

// Envia/troca a foto de perfil. Retorna a URL salva.
export async function enviarFotoPerfil(fileUri: string): Promise<string> {
  const data = await apiUpload('/aluno/upload_foto_perfil.php', {}, fileUri);
  return data.fotoUrl;
}

// Remove a foto de perfil (apaga o arquivo e zera no banco).
export async function removerFotoPerfil(): Promise<void> {
  await apiPost('/aluno/remover_foto_perfil.php', {});
}

// Exclusão permanente da própria conta (LGPD) — exige nome + senha.
export async function excluirMinhaConta(
  nomeConfirmacao: string,
  senha: string
): Promise<void> {
  await apiDelete('/aluno/excluir_conta.php', { nomeConfirmacao, senha });
}
