// =============================================
// CLIENTE HTTP CENTRAL
// =============================================
// É o ÚNICO ponto do app que fala com o backend PHP.
// Todo serviço (auth, aluno, ...) usa as funções daqui.
// - Lê a URL base de config/api.ts (trocar IP = mexer em 1 lugar só).
// - Anexa o token de autenticação automaticamente em cada request.
// - Padroniza o tratamento de erro (lança Error com a mensagem do PHP).

import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../config/api';

const TOKEN_KEY = '@app:token';

// ---- Token de sessão (guardado no dispositivo) ----
export async function getToken(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}
export async function setToken(token: string): Promise<void> {
  await AsyncStorage.setItem(TOKEN_KEY, token);
}
export async function clearToken(): Promise<void> {
  await AsyncStorage.removeItem(TOKEN_KEY);
}

// Monta os headers, incluindo Authorization se houver token
async function authHeaders(extra: Record<string, string> = {}) {
  const token = await getToken();
  const headers: Record<string, string> = { ...extra };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

// Trata a resposta: parseia JSON e lança erro com a mensagem do servidor
async function handle(res: Response): Promise<any> {
  let data: any = null;
  const text = await res.text();
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    // resposta não-JSON (erro de servidor, HTML de erro do PHP, etc.)
    throw new Error(`Resposta inválida do servidor (HTTP ${res.status}).`);
  }
  if (!res.ok) {
    throw new Error(data?.message || `Erro HTTP ${res.status}.`);
  }
  return data;
}

// ---- Verbos JSON ----
export async function apiGet(caminho: string): Promise<any> {
  const res = await fetch(`${API_BASE_URL}${caminho}`, {
    method: 'GET',
    headers: await authHeaders(),
  });
  return handle(res);
}

export async function apiPost(caminho: string, body: any = {}): Promise<any> {
  const res = await fetch(`${API_BASE_URL}${caminho}`, {
    method: 'POST',
    headers: await authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  });
  return handle(res);
}

export async function apiPut(caminho: string, body: any = {}): Promise<any> {
  const res = await fetch(`${API_BASE_URL}${caminho}`, {
    method: 'PUT',
    headers: await authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  });
  return handle(res);
}

// DELETE manda corpo via POST-like (alguns servidores barram corpo em DELETE)
export async function apiDelete(caminho: string, body: any = {}): Promise<any> {
  const res = await fetch(`${API_BASE_URL}${caminho}`, {
    method: 'POST', // o endpoint aceita POST e DELETE
    headers: await authHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(body),
  });
  return handle(res);
}

// ---- Upload multipart (foto) ----
// uri vem do ImagePicker (file:// no celular). Monta FormData.
export async function apiUpload(
  caminho: string,
  campos: Record<string, string>,
  fileUri: string,
  fieldName = 'foto'
): Promise<any> {
  const form = new FormData();
  for (const [k, v] of Object.entries(campos)) form.append(k, v);

  // Descobre extensão/tipo a partir da URI
  const ext = (fileUri.split('.').pop() || 'jpg').toLowerCase();
  const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
  // @ts-ignore — formato aceito pelo React Native para arquivos
  form.append(fieldName, { uri: fileUri, name: `foto.${ext}`, type: mime });

  const res = await fetch(`${API_BASE_URL}${caminho}`, {
    method: 'POST',
    headers: await authHeaders(), // NÃO setar Content-Type: o fetch põe o boundary
    body: form,
  });
  return handle(res);
}
