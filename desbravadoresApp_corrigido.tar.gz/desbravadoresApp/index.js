import { registerRootComponent } from 'expo';

import App from './App';

// registerRootComponent chama AppRegistry.registerComponent('main', () => App)
// e, na web, AppRegistry.runApplication para montar no <div id="root">.
// Sem isto, o App é importado mas nunca é renderizado (tela branca).
registerRootComponent(App);
