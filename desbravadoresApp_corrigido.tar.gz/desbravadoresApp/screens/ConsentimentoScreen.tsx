import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radii, spacing } from '../styles/theme';

// Tela de CONSENTIMENTO (LGPD). Lista exatamente o que o app coleta e faz,
// pra a pessoa marcar o checkbox de cadastro consciente disso.
const ITENS = [
  { t: 'Nome', d: 'Para identificar você no clube e nos relatórios.' },
  { t: 'E-mail', d: 'Para login, recuperação de senha e contato.' },
  { t: 'Data de nascimento', d: 'Para calcular sua idade e organizar as classes.' },
  { t: 'Senha', d: 'Guardada de forma criptografada — nem o clube vê sua senha real.' },
  { t: 'Progresso nas classes', d: 'Quais requisitos você marcou como cumpridos e em qual classe está.' },
  { t: 'Fotos de evidência', d: 'As imagens que você envia para comprovar um requisito.' },
  { t: 'Histórico de classes', d: 'Quais classes você concluiu, quando e qual professor aprovou.' },
];

export default function ConsentimentoScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.titulo}>Consentimento de Dados</Text>
        <Text style={styles.intro}>
          Para usar o aplicativo, precisamos coletar e guardar alguns dados seus.
          Veja exatamente o que é coletado e para quê:
        </Text>

        {ITENS.map((item, i) => (
          <View key={i} style={styles.card}>
            <Text style={styles.cardTitulo}>• {item.t}</Text>
            <Text style={styles.cardDesc}>{item.d}</Text>
          </View>
        ))}

        <Text style={styles.h}>Quem vê seus dados</Text>
        <Text style={styles.p}>
          Apenas você e o professor responsável pelo seu clube. Seus dados não são
          vendidos nem compartilhados com terceiros.
        </Text>

        <Text style={styles.h}>Seus direitos</Text>
        <Text style={styles.p}>
          Você pode excluir permanentemente sua conta e todos os seus dados a qualquer
          momento, na tela de Perfil. Ao excluir, tudo é apagado de forma definitiva.
        </Text>

        <View style={styles.aviso}>
          <Text style={styles.avisoText}>
            Ao marcar o consentimento na tela de cadastro, você declara estar ciente e
            de acordo com a coleta e o uso desses dados conforme descrito acima.
          </Text>
        </View>

        <TouchableOpacity style={styles.botao} onPress={() => navigation.goBack()}>
          <Text style={styles.botaoText}>Voltar ao cadastro</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: spacing.xl, paddingBottom: 40 },
  titulo: { fontSize: 22, fontWeight: 'bold', color: colors.accent, marginBottom: spacing.sm },
  intro: { color: colors.text, fontSize: 14, lineHeight: 21, marginBottom: spacing.lg },
  card: {
    backgroundColor: colors.card, borderRadius: radii.md, padding: spacing.md,
    marginBottom: spacing.sm, borderLeftWidth: 3, borderLeftColor: colors.accent,
  },
  cardTitulo: { color: colors.accent, fontWeight: '700', fontSize: 14 },
  cardDesc: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: 2 },
  h: { color: colors.accent, fontWeight: '700', fontSize: 15, marginTop: spacing.lg, marginBottom: 4 },
  p: { color: colors.text, fontSize: 14, lineHeight: 21 },
  aviso: {
    backgroundColor: colors.cardSunk, borderLeftWidth: 4, borderLeftColor: colors.accent,
    padding: spacing.md, borderRadius: radii.sm, marginTop: spacing.lg,
  },
  avisoText: { color: colors.text, fontSize: 13, lineHeight: 20, fontStyle: 'italic' },
  botao: { backgroundColor: colors.accent, padding: 14, borderRadius: radii.md, alignItems: 'center', marginTop: spacing.xl },
  botaoText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 16 },
});
