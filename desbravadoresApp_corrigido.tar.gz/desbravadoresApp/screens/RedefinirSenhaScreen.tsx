import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
} from 'react-native';
import { atualizarSenha } from '../services/auth';
import { colors, radii, spacing, common } from '../styles/theme';

export default function RedefinirSenhaScreen({ navigation, route }) {
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [loading, setLoading] = useState(false);

  const token = route.params?.token || '';

  const handleUpdatePassword = async () => {
    if (novaSenha.length < 8) {
      Alert.alert('Erro', 'A senha deve ter no mínimo 8 caracteres.');
      return;
    }
    if (novaSenha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }
    setLoading(true);
    try {
      const msg = await atualizarSenha(token, novaSenha);
      Alert.alert('Sucesso', msg);
      navigation.navigate('Login');
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha na conexão com o servidor.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <View style={styles.card}>
        <Text style={styles.title}>Nova Senha</Text>
        <Text style={styles.subtitle}>Crie uma nova senha de acesso</Text>

        <TextInput
          style={styles.input}
          placeholder="Nova Senha (mínimo 8 caracteres)"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={novaSenha}
          onChangeText={setNovaSenha}
          maxLength={24}
        />
        <TextInput
          style={styles.input}
          placeholder="Confirmar Nova Senha"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={confirmarSenha}
          onChangeText={setConfirmarSenha}
          maxLength={24}
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleUpdatePassword}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? 'Salvando...' : 'Redefinir Senha'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.link}>Voltar para login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, justifyContent: 'center', padding: spacing.xl },
  card: {
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    padding: spacing.xl,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
    elevation: 5,
  },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', color: colors.accent, marginBottom: 8 },
  subtitle: { fontSize: 14, textAlign: 'center', color: colors.textMuted, marginBottom: spacing.xl },
  input: common.input,
  button: common.buttonPrimary,
  buttonDisabled: { opacity: 0.6 },
  buttonText: common.buttonPrimaryText,
  link: { textAlign: 'center', color: colors.accent, marginTop: 15, fontWeight: '500' },
});
