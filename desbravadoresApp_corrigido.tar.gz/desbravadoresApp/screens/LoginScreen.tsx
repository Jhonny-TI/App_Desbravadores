import React, { useState } from 'react';
import {
  Text,
  View,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
} from 'react-native';
import { colors, radii, spacing, common } from '../styles/theme';
import { login } from '../services/auth';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [tipoUsuario, setTipoUsuario] = useState('aluno');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !senha) {
      Alert.alert('Erro', 'Por favor, preencha o e-mail e a senha.');
      return;
    }
    setLoading(true);
    try {
      const usuario = await login(email.trim(), senha);

      // Se a conta foi criada pelo painel (senha provisória) ou ainda não
      // aceitou os termos, manda pro fluxo de primeiro acesso.
      if (usuario.senhaProvisoria || !usuario.termosAceitos) {
        navigation.navigate('PrimeiroAcesso');
        return;
      }

      // Redireciona pelo papel: aluno -> Home; professor -> painel.
      if (usuario.tipo === 'aluno') {
        navigation.navigate('Home');
      } else {
        navigation.navigate('PainelProfessor');
      }
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível entrar.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <View style={styles.card}>
        <View style={styles.logoContainer}>
          <Image source={require('../assets/img/icone.jpeg')} style={styles.logo} />
        </View>

        <Text style={styles.titulo}>Bem-vindo</Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor={colors.placeholder}
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <TextInput
          style={styles.input}
          placeholder="Senha"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />

        <View style={styles.tipoContainer}>
          <TouchableOpacity
            style={[styles.tipoBotao, tipoUsuario === 'aluno' && styles.tipoSelecionado]}
            onPress={() => setTipoUsuario('aluno')}
          >
            <Text style={tipoUsuario === 'aluno' ? styles.tipoTextoSelecionado : styles.tipoTexto}>
              Aluno
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tipoBotao, tipoUsuario === 'professor' && styles.tipoSelecionado]}
            onPress={() => setTipoUsuario('professor')}
          >
            <Text style={tipoUsuario === 'professor' ? styles.tipoTextoSelecionado : styles.tipoTexto}>
              Professor
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={[styles.botao, loading && { opacity: 0.6 }]} onPress={handleLogin} disabled={loading}>
          <Text style={styles.textoBotao}>{loading ? 'Entrando...' : 'Entrar'}</Text>
        </TouchableOpacity>

        <View style={styles.extraContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('RecuperarEmail')}>
            <Text style={styles.link}>Recuperar senha</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('CriarConta')}>
            <Text style={styles.link}>Criar conta</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Home')}>
            <Text style={styles.linkSecundario}>Voltar para Home</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, justifyContent: 'center', padding: spacing.xl },
  card: {
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    padding: spacing.xl,
    // Borda lateral amarela — assinatura visual do tema (vinda do RequisitoScreen)
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
    elevation: 5,
  },
  logoContainer: { alignSelf: 'center', marginBottom: spacing.md },
  logo: {
    width: 90,
    height: 90,
    borderRadius: 45,
    borderWidth: 3,
    borderColor: colors.accent,
  },
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    color: colors.accent,
    marginBottom: spacing.xl,
  },
  input: common.input,
  tipoContainer: { flexDirection: 'row', marginBottom: spacing.lg },
  tipoBotao: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: radii.sm,
    backgroundColor: colors.cardSunk,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: colors.border,
  },
  tipoSelecionado: { backgroundColor: colors.accent, borderColor: colors.accent },
  tipoTexto: { textAlign: 'center', fontWeight: 'bold', color: colors.textMuted },
  tipoTextoSelecionado: { color: colors.onAccent, textAlign: 'center', fontWeight: 'bold' },
  botao: common.buttonPrimary,
  textoBotao: common.buttonPrimaryText,
  extraContainer: { marginTop: spacing.lg, alignItems: 'center' },
  link: { color: colors.accent, marginTop: 10, fontWeight: '500' },
  linkSecundario: { color: colors.textMuted, marginTop: 10 },
});
