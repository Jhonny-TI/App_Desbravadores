import React, { useState, useRef, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  StatusBar,
  Pressable,
  Image,
  FlatList,
  Dimensions,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radii, spacing } from '../styles/theme';
import { useAuth } from '../hooks/useAuth';
import { logout } from '../services/auth';

const { width } = Dimensions.get('window');

// Intervalo do autoplay do carrossel (ms). Reinicia se o usuário arrastar.
const AUTOPLAY_MS = 30000;

// Carrossel de classes — cada item leva pra ClassScreen daquela classe.
// O modo (leitura/edição) é decidido lá dentro, com base no usuário logado.
const CAROUSEL_DATA = [
  { id: '1', name: 'Amigo',         image: require('../assets/cards/classeAmigo.png') },
  { id: '2', name: 'Companheiro',   image: require('../assets/cards/classeCompanheiro.png') },
  { id: '3', name: 'Pesquisador',   image: require('../assets/cards/classePesquisador.png') },
  { id: '4', name: 'Pioneiro',      image: require('../assets/cards/classePioneiro.png') },
  { id: '5', name: 'Excursionista', image: require('../assets/cards/classeExcursionista.png') },
  { id: '6', name: 'Guia',          image: require('../assets/cards/classeGuia.png') },
];

// Marcos históricos (timeline da seção "Sobre")
// Mantidos apenas os marcos confirmados em múltiplas fontes independentes.
const HISTORIA = [
  { ano: '1946', texto: 'Primeiro Clube de Desbravadores patrocinado por uma Associação, em Riverside, Califórnia. O Pr. John Hancock desenha o emblema triangular, usado até hoje no mundo inteiro.' },
  { ano: '1950', texto: 'A Associação Geral da Igreja Adventista do Sétimo Dia oficializa o movimento como um programa mundial.' },
  { ano: '1953', texto: 'Realizado o primeiro Campori internacional, em Camp Winnekeag, Massachusetts (EUA).' },
  { ano: '1955', texto: 'Surge o primeiro clube na América do Sul, em Lima (Peru), liderado pelo casal Nercida e Armando Ruiz. Nasce o nome "Conquistadores" em espanhol.' },
];

export default function HomeScreen({ navigation }) {
  const [menuVisible, setMenuVisible] = useState(false);
  const { user, refresh } = useAuth();

  // --- AUTOPLAY do carrossel ---
  // Refs (não state) porque a gente não precisa re-renderizar a cada troca.
  const flatListRef = useRef<FlatList>(null);
  const currentIndexRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // (Re)agenda o próximo "salto" do carrossel para daqui a AUTOPLAY_MS.
  // Cada chamada cancela o timer anterior — é assim que o reset funciona
  // quando o usuário arrasta manualmente.
  const scheduleNext = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      const next = (currentIndexRef.current + 1) % CAROUSEL_DATA.length;
      // scrollToOffset é mais previsível que scrollToIndex com pagingEnabled
      // (cada "página" do carrossel mede exatamente `width` na horizontal).
      flatListRef.current?.scrollToOffset({ offset: next * width, animated: true });
      currentIndexRef.current = next;
      scheduleNext(); // encadeia o próximo
    }, AUTOPLAY_MS);
  }, []);

  // Liga o autoplay enquanto a tela estiver em foco, pausa quando sai
  // (evita o carrossel ficar rodando invisível enquanto o usuário está em outra tela).
  useFocusEffect(
    useCallback(() => {
      scheduleNext();
      return () => {
        if (timerRef.current) clearTimeout(timerRef.current);
      };
    }, [scheduleNext])
  );

  // Usuário começou a arrastar → cancela o agendamento atual
  const handleScrollBeginDrag = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
  };

  // Usuário soltou e a animação de inércia terminou → atualiza o índice atual
  // e reinicia o relógio dos 30s a partir de agora.
  const handleMomentumScrollEnd = (e: any) => {
    const idx = Math.round(e.nativeEvent.contentOffset.x / width);
    currentIndexRef.current = idx;
    scheduleNext();
  };

  const handleSair = async () => {
    setMenuVisible(false);
    await logout();
    refresh(); // re-lê do AsyncStorage e atualiza o header
  };

  const handleBannerPress = (className: string) => {
    // Sempre navega pra ClassScreen com o nome da classe.
    // A ClassScreen decide se mostra em modo leitura ou edição.
    navigation.navigate('Requisito', { screen: 'Classe', params: { name: className } });
  };

  const renderBanner = ({ item }) => (
    <TouchableOpacity
      activeOpacity={0.85}
      style={styles.card}
      onPress={() => handleBannerPress(item.name)}
    >
      <Image
        source={typeof item.image === 'string' ? { uri: item.image } : item.image}
        style={styles.fullImage}
      />
    </TouchableOpacity>
  );

  // Inicial do nome para usar como "avatar" quando logado e sem foto
  const inicial = user?.nome?.[0]?.toUpperCase() ?? '?';

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      {/* HEADER */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image
            source={require('../assets/icones/desbravIcone.png')}
            style={styles.logoTopo}
            resizeMode="contain"
          />
        </View>

        <View style={styles.headerRight}>
          {user ? (
            // LOGADO: avatar com inicial + menu de pontos
            <>
              <TouchableOpacity
                style={styles.avatarBtn}
                onPress={() => setMenuVisible((v) => !v)}
              >
                <Text style={styles.avatarText}>{inicial}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.pontosBtn} onPress={() => setMenuVisible((v) => !v)}>
                <Image source={require('../assets/icones/dots.png')} style={styles.imagemPontos} resizeMode="contain" />
              </TouchableOpacity>
            </>
          ) : (
            // DESLOGADO: botão Login
            <TouchableOpacity style={styles.loginSmallBtn} onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginText}>Login</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* MENU DROPDOWN (só faz sentido se logado) */}
      {menuVisible && user && (
        <>
          <Pressable style={styles.menuOverlay} onPress={() => setMenuVisible(false)} />
          <View style={styles.dropdownMenu}>
            <View style={styles.menuHeader}>
              <Text style={styles.menuHeaderNome} numberOfLines={1}>{user.nome}</Text>
              <Text style={styles.menuHeaderEmail} numberOfLines={1}>{user.email}</Text>
            </View>
            <View style={styles.menuDivider} />
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => { setMenuVisible(false); navigation.navigate('Perfil'); }}
            >
              <Image source={require('../assets/icones/user.png')} style={styles.menuIcon} />
              <Text style={styles.menuItemText}>Perfil</Text>
            </TouchableOpacity>
            <View style={styles.menuDivider} />
            <TouchableOpacity style={styles.menuItem} onPress={handleSair}>
              <Image source={require('../assets/icones/exit.png')} style={styles.menuIcon} />
              <Text style={[styles.menuItemText, { color: colors.danger }]}>Sair</Text>
            </TouchableOpacity>
          </View>
        </>
      )}

      {/* CONTEÚDO ROLÁVEL */}
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.welcomeContainer}>
          <Text style={styles.welcomeText}>Mural do Desbravador</Text>
          <Text style={styles.infoText}>
            {user
              ? `Olá, ${user.nome}! Conheça as classes e acompanhe seu progresso.`
              : 'Onde a Aventura Começa!'}
          </Text>
        </View>

        {/* Carrossel de classes */}
        <Text style={styles.sectionTitle}>Classes</Text>
        <Text style={styles.sectionSubtitle}>Toque em uma classe para ver os requisitos.</Text>
        <View style={styles.carouselWrapper}>
          <FlatList
            ref={flatListRef}
            data={CAROUSEL_DATA}
            renderItem={renderBanner}
            keyExtractor={(item) => item.id}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            snapToAlignment="center"
            decelerationRate="fast"
            onScrollBeginDrag={handleScrollBeginDrag}
            onMomentumScrollEnd={handleMomentumScrollEnd}
          />
        </View>

        {/* Sobre os Desbravadores */}
        <Text style={styles.sectionTitle}>Sobre os Desbravadores</Text>
        <View style={styles.aboutCard}>
          <Image source={require('../assets/img/desbravImage.png')} style={styles.aboutImage} />
          <Text style={styles.aboutText}>
            O Clube de Desbravadores é um movimento juvenil da Igreja Adventista do Sétimo Dia.
          </Text>
          <Text style={styles.aboutText}>
            Suas raízes remontam ao início do século XX, com as primeiras Sociedades de Jovens
            Adventistas. Em 1919, Arthur W. Spalding organizou a Missão dos Sentinelas em
            Madison, Tennessee — uma das bases do que viria a ser o Clube de Desbravadores.
            O modelo que conhecemos hoje, porém, nasceu na Califórnia em 1946.
          </Text>
        </View>

        {/* Timeline */}
        <Text style={styles.timelineHeader}>Marcos da história</Text>
        <View style={styles.timeline}>
          {HISTORIA.map((m, i) => (
            <View key={m.ano} style={styles.timelineItem}>
              <View style={styles.timelineYearCol}>
                <View style={styles.timelineDot} />
                {i < HISTORIA.length - 1 && <View style={styles.timelineLine} />}
              </View>
              <View style={styles.timelineBody}>
                <Text style={styles.timelineYear}>{m.ano}</Text>
                <Text style={styles.timelineText}>{m.texto}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* BARRA INFERIOR */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Home')}>
          <Image source={require('../assets/icones/home.png')} style={[styles.navIcon, styles.navIconActive]} />
          <Text style={styles.navTextActive}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navItem} onPress={() => navigation.navigate('Requisito')}>
          <Image source={require('../assets/icones/progress.png')} style={styles.navIcon} />
          <Text style={styles.navText}>Progresso</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scrollContent: { paddingBottom: spacing.xxl },

  /* HEADER */
  header: {
    height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    zIndex: 10,
  },
  headerLeft: { flex: 1, justifyContent: 'center', alignItems: 'flex-start' },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  loginSmallBtn: {
    backgroundColor: colors.accent,
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: radii.sm,
  },
  loginText: { color: colors.onAccent, fontWeight: '700', fontSize: 14 },
  // Avatar circular com a inicial do usuário logado
  avatarBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 6,
  },
  avatarText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 16 },
  pontosBtn: { padding: 8, width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  imagemPontos: { width: '100%', height: '100%', tintColor: colors.text },
  logoTopo: { width: 45, height: 45 },

  /* Menu dropdown */
  menuOverlay: { ...StyleSheet.absoluteFillObject, zIndex: 5 },
  dropdownMenu: {
    position: 'absolute',
    top: 60,
    right: 20,
    backgroundColor: colors.card,
    width: 220,
    borderRadius: radii.md,
    paddingVertical: 4,
    zIndex: 20,
    borderWidth: 1,
    borderColor: colors.border,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
  },
  menuHeader: { paddingHorizontal: 14, paddingVertical: 10 },
  menuHeaderNome: { color: colors.text, fontWeight: '700', fontSize: 14 },
  menuHeaderEmail: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  menuItem: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 14, alignItems: 'center' },
  menuItemText: { fontSize: 15, color: colors.text, fontWeight: '500' },
  menuDivider: { height: 1, backgroundColor: colors.border },
  menuIcon: { width: 16, height: 16, marginRight: 10, resizeMode: 'contain', tintColor: colors.text },

  /* Welcome */
  welcomeContainer: { paddingHorizontal: spacing.xl, marginTop: spacing.md, marginBottom: spacing.xl },
  welcomeText: { fontSize: 22, fontWeight: 'bold', color: colors.accent },
  infoText: { color: colors.textMuted, marginTop: 4 },

  /* Section header reutilizável */
  sectionTitle: {
    fontSize: 18,
    color: colors.accent,
    fontWeight: 'bold',
    paddingHorizontal: spacing.xl,
    marginTop: spacing.md,
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: colors.textMuted,
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.md,
  },

  /* Carrossel */
  carouselWrapper: { height: 180, marginBottom: spacing.lg },
  card: {
    width: width - 40,
    height: 180,
    marginHorizontal: spacing.xl,
    borderRadius: radii.lg,
    overflow: 'hidden',
    backgroundColor: colors.card,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
  },
  fullImage: { width: '100%', height: '100%', resizeMode: 'cover' },

  /* Sobre */
  aboutCard: {
    backgroundColor: colors.card,
    marginHorizontal: spacing.xl,
    borderRadius: radii.lg,
    padding: spacing.lg,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
    marginBottom: spacing.lg,
  },
  aboutImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
    borderRadius: radii.md,
    marginBottom: spacing.md,
  },
  aboutText: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 21,
    marginBottom: spacing.sm,
  },

  /* Timeline */
  timelineHeader: {
    fontSize: 15,
    color: colors.accent,
    fontWeight: '700',
    paddingHorizontal: spacing.xl,
    marginTop: 4,
    marginBottom: spacing.md,
  },
  timeline: { paddingHorizontal: spacing.xl },
  timelineItem: { flexDirection: 'row' },
  timelineYearCol: { width: 22, alignItems: 'center' },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.accent,
    marginTop: 6,
  },
  timelineLine: { width: 2, flex: 1, backgroundColor: colors.border, marginTop: 2 },
  timelineBody: { flex: 1, paddingLeft: spacing.md, paddingBottom: spacing.lg },
  timelineYear: { color: colors.accent, fontWeight: 'bold', fontSize: 15 },
  timelineText: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: 2 },

  /* Barra Inferior */
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    height: 80,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingBottom: 20,
  },
  navIcon: { width: 24, height: 24, marginBottom: 4, resizeMode: 'contain', tintColor: colors.textMuted },
  navIconActive: { tintColor: colors.accent },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navText: { fontSize: 12, color: colors.textMuted },
  navTextActive: { fontSize: 12, color: colors.accent, fontWeight: 'bold' },
});
