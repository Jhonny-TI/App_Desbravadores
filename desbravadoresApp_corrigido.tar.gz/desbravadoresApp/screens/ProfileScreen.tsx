import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import React, { useState, useCallback } from 'react';
import {
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  StatusBar,
  Modal,
  Alert,
  ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radii, spacing, common } from '../styles/theme';
import { logout, getUser, setUser } from '../services/auth';
import { excluirMinhaConta, getPerfil, atualizarPerfil, enviarFotoPerfil, removerFotoPerfil } from '../services/aluno';

export default function ProfileScreen({ navigation }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [nomeConf, setNomeConf] = useState('');
  const [senhaConf, setSenhaConf] = useState('');
  const [excluindo, setExcluindo] = useState(false);

  // Dados reais do usuário logado + estatísticas
  const [perfil, setPerfil] = useState(null);
  const [stats, setStats] = useState({ concluidas: 0, requisitos: 0 });

  // --- Formulário de edição ---
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [confirmarEmail, setConfirmarEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [senhaAtual, setSenhaAtual] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [fotoLoading, setFotoLoading] = useState(false);

  // Preenche os campos editáveis com os dados atuais (e ao descartar)
  const sincronizarCampos = (u: any) => {
    setNome(u?.nome || '');
    setEmail(u?.email || '');
    setConfirmarEmail(u?.email || '');
    setSenha('');
    setConfirmarSenha('');
    setSenhaAtual('');
  };

  // --- Foto de perfil ---
  const escolherFoto = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.6 });
    if (result.canceled) return;
    setFotoLoading(true);
    try {
      const url = await enviarFotoPerfil(result.assets[0].uri);
      const u = { ...perfil, fotoUrl: url };
      await setUser(u); setPerfil(u);
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha ao enviar a foto.');
    } finally {
      setFotoLoading(false);
    }
  };

  const apagarFoto = () => {
    Alert.alert('Remover foto', 'Deseja remover sua foto de perfil?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Remover', style: 'destructive',
        onPress: async () => {
          setFotoLoading(true);
          try {
            await removerFotoPerfil();
            const u = { ...perfil, fotoUrl: null };
            await setUser(u); setPerfil(u);
          } catch (e: any) {
            Alert.alert('Erro', e.message || 'Falha ao remover a foto.');
          } finally {
            setFotoLoading(false);
          }
        },
      },
    ]);
  };

  const descartar = () => {
    sincronizarCampos(perfil);
  };

  const salvar = async () => {
    // Monta só o que mudou
    const mudancas: any = {};
    if (nome.trim() && nome.trim() !== perfil?.nome) {
      if (nome.trim().length < 3) { Alert.alert('Erro', 'O nome deve ter no mínimo 3 caracteres.'); return; }
      mudancas.nome = nome.trim();
    }
    if (email.trim() !== perfil?.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) { Alert.alert('Erro', 'E-mail inválido.'); return; }
      if (email.trim() !== confirmarEmail.trim()) { Alert.alert('Erro', 'Os e-mails não coincidem.'); return; }
      mudancas.email = email.trim();
    }
    if (senha) {
      if (senha.length < 8) { Alert.alert('Erro', 'A nova senha deve ter no mínimo 8 caracteres.'); return; }
      if (senha !== confirmarSenha) { Alert.alert('Erro', 'As senhas não coincidem.'); return; }
      mudancas.senha = senha;
    }
    if (Object.keys(mudancas).length === 0) {
      Alert.alert('Aviso', 'Nenhuma alteração para salvar.');
      return;
    }
    // Mudança sensível (email ou senha) exige a senha atual
    const sensivel = 'email' in mudancas || 'senha' in mudancas;
    if (sensivel) {
      if (!senhaAtual) { Alert.alert('Erro', 'Digite sua senha atual para confirmar a alteração.'); return; }
      mudancas.senhaAtual = senhaAtual;
    }
    setSalvando(true);
    try {
      const r = await atualizarPerfil(mudancas);
      // Atualiza o usuário local com o que voltou do servidor
      const u = r.usuario || { ...perfil, ...mudancas };
      await setUser(u);
      setPerfil(u);
      sincronizarCampos(u);
      Alert.alert('Pronto', 'Dados atualizados com sucesso.');
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível salvar.');
    } finally {
      setSalvando(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      let ativo = true;
      (async () => {
        const u = await getUser();
        if (ativo && u) { setPerfil(u); sincronizarCampos(u); }
        try {
          const p = await getPerfil();
          if (ativo) {
            setPerfil(p.usuario);
            sincronizarCampos(p.usuario);
            setStats({ concluidas: p.totalConcluidas ?? 0, requisitos: p.totalRequisitos ?? 0 });
          }
        } catch {
          // sem rede: mantém o que veio do getUser local
        }
      })();
      return () => { ativo = false; };
    }, [])
  );

  const handleSair = async () => {
    await logout();
    navigation.reset({ index: 0, routes: [{ name: 'Home' }] });
  };

  const handleExcluir = async () => {
    setExcluindo(true);
    try {
      await excluirMinhaConta(nomeConf.trim(), senhaConf);
      setModalVisible(false);
      Alert.alert('Conta excluída', 'Sua conta foi excluída permanentemente.');
      navigation.reset({ index: 0, routes: [{ name: 'Home' }] });
    } catch (e) {
      Alert.alert('Erro', e.message || 'Não foi possível excluir a conta.');
    } finally {
      setExcluindo(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Cabeçalho do Desbravador */}
        <View style={styles.header}>
          <View style={styles.avatarContainer}>
            <Image
              style={styles.avatar}
              source={{
                uri: perfil?.fotoUrl
                  ? perfil.fotoUrl
                  : `https://ui-avatars.com/api/?name=${encodeURIComponent(perfil?.nome || 'Desbravador')}&background=facc15&color=0f172a&size=150`,
              }}
            />
            {fotoLoading && (
              <View style={styles.avatarLoading}><ActivityIndicator color={colors.accent} /></View>
            )}
            {/* Botão de trocar foto */}
            <TouchableOpacity style={styles.fotoEditBtn} onPress={escolherFoto} disabled={fotoLoading}>
              <Ionicons name="camera" size={16} color={colors.onAccent} />
            </TouchableOpacity>
            {/* Lixeira (só aparece se tem foto real enviada) */}
            {perfil?.fotoUrl && (
              <TouchableOpacity style={styles.fotoTrashBtn} onPress={apagarFoto} disabled={fotoLoading}>
                <Ionicons name="trash" size={15} color="#fff" />
              </TouchableOpacity>
            )}
          </View>

          <Text style={styles.name}>{perfil?.nome || '—'}</Text>
          <Text style={styles.bio}>{perfil?.email || ''}</Text>

          <View style={styles.badgesContainer}>
            <View style={styles.classBadge}>
              <Text style={styles.classText}>Classe: {perfil?.classe || '—'}</Text>
            </View>
            {perfil?.idade != null && (
              <View style={styles.ageBadge}>
                <Text style={styles.ageText}>{perfil.idade} anos</Text>
              </View>
            )}
          </View>
        </View>

        {/* Estatísticas reais (crescem conforme o aluno avança) */}
        <View style={styles.statsContainer}>
          <View style={styles.statBox}>
            <MaterialCommunityIcons name="shield-star-outline" size={28} color={colors.accent} />
            <Text style={styles.statNumber}>{stats.concluidas}</Text>
            <Text style={styles.statLabel}>Classes concluídas</Text>
          </View>

          <View style={styles.statDivider} />

          <View style={styles.statBox}>
            <MaterialCommunityIcons name="checkbox-marked-circle-outline" size={28} color={colors.success} />
            <Text style={styles.statNumber}>{stats.requisitos}</Text>
            <Text style={styles.statLabel}>Requisitos cumpridos</Text>
          </View>
        </View>

        {/* Formulário de edição da conta */}
        <View style={styles.form}>
          <Text style={styles.formTitulo}>Editar dados da conta</Text>

          <Text style={styles.label}>Nome</Text>
          <TextInput style={common.input} value={nome} onChangeText={setNome}
            placeholder="Seu nome" placeholderTextColor={colors.placeholder} />

          <Text style={styles.label}>E-mail</Text>
          <TextInput style={common.input} value={email} onChangeText={setEmail}
            placeholder="seu@email.com" placeholderTextColor={colors.placeholder}
            keyboardType="email-address" autoCapitalize="none" />

          <Text style={styles.label}>Confirmar e-mail</Text>
          <TextInput style={common.input} value={confirmarEmail} onChangeText={setConfirmarEmail}
            placeholder="repita o e-mail" placeholderTextColor={colors.placeholder}
            keyboardType="email-address" autoCapitalize="none" />

          <Text style={styles.label}>Nova senha</Text>
          <TextInput style={common.input} value={senha} onChangeText={setSenha}
            placeholder="deixe em branco para não mudar" placeholderTextColor={colors.placeholder}
            secureTextEntry />

          <Text style={styles.label}>Confirmar nova senha</Text>
          <TextInput style={common.input} value={confirmarSenha} onChangeText={setConfirmarSenha}
            placeholder="repita a nova senha" placeholderTextColor={colors.placeholder}
            secureTextEntry />

          <Text style={styles.label}>Senha atual</Text>
          <TextInput style={common.input} value={senhaAtual} onChangeText={setSenhaAtual}
            placeholder="obrigatória para mudar e-mail ou senha" placeholderTextColor={colors.placeholder}
            secureTextEntry />
          <Text style={styles.dica}>Sua senha atual é exigida apenas ao alterar o e-mail ou a senha.</Text>

          <View style={styles.formBotoes}>
            <TouchableOpacity style={styles.btnDescartar} onPress={descartar} disabled={salvando}>
              <Text style={styles.btnDescartarText}>Descartar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.btnSalvar, salvando && { opacity: 0.6 }]} onPress={salvar} disabled={salvando}>
              <Text style={styles.btnSalvarText}>{salvando ? 'Salvando...' : 'Salvar'}</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Sair */}
        <TouchableOpacity style={styles.logoutButton} activeOpacity={0.8} onPress={handleSair}>
          <Ionicons name="log-out-outline" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.logoutButtonText}>Sair da Conta</Text>
        </TouchableOpacity>

        {/* Excluir conta permanentemente (LGPD) */}
        <TouchableOpacity
          style={styles.deleteButton}
          activeOpacity={0.8}
          onPress={() => { setNomeConf(''); setSenhaConf(''); setModalVisible(true); }}
        >
          <Text style={styles.deleteButtonText}>Excluir minha conta permanentemente</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* MODAL de confirmação de exclusão */}
      <Modal visible={modalVisible} transparent animationType="fade" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Excluir conta</Text>
            <Text style={styles.modalWarn}>
              Esta ação é permanente e não pode ser desfeita. Todo o seu progresso,
              classes concluídas e fotos serão apagados.
            </Text>
            <Text style={styles.modalLabel}>Digite seu nome completo para confirmar:</Text>
            <TextInput
              style={common.input}
              placeholder="Seu nome"
              placeholderTextColor={colors.placeholder}
              value={nomeConf}
              onChangeText={setNomeConf}
            />
            <Text style={styles.modalLabel}>Digite sua senha:</Text>
            <TextInput
              style={common.input}
              placeholder="Senha"
              placeholderTextColor={colors.placeholder}
              secureTextEntry
              value={senhaConf}
              onChangeText={setSenhaConf}
            />
            <View style={styles.modalRow}>
              <TouchableOpacity style={styles.modalCancel} onPress={() => setModalVisible(false)}>
                <Text style={styles.modalCancelText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalConfirm, excluindo && { opacity: 0.6 }]}
                onPress={handleExcluir}
                disabled={excluindo}
              >
                <Text style={styles.modalConfirmText}>{excluindo ? 'Excluindo...' : 'Excluir'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scrollContent: { padding: spacing.xl, alignItems: 'center' },
  header: { alignItems: 'center', marginTop: spacing.lg, marginBottom: spacing.xl },
  avatarContainer: { position: 'relative', marginBottom: spacing.md },
  fotoEditBtn: {
    position: 'absolute', bottom: 0, right: 0, backgroundColor: colors.accent,
    width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center',
    borderWidth: 3, borderColor: colors.bg,
  },
  fotoTrashBtn: {
    position: 'absolute', bottom: 0, left: 0, backgroundColor: colors.danger,
    width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center',
    borderWidth: 3, borderColor: colors.bg,
  },
  avatarLoading: {
    ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(15,23,42,0.6)',
    borderRadius: 60, alignItems: 'center', justifyContent: 'center',
  },
  dica: { color: colors.textMuted, fontSize: 11, marginTop: 4, fontStyle: 'italic' },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: colors.accent,
  },
  editBadge: {
    position: 'absolute',
    bottom: 0,
    right: 5,
    backgroundColor: colors.accent,
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.bg,
  },
  nameContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  name: { fontSize: 24, fontWeight: 'bold', color: colors.text, marginTop: 4, textAlign: 'center' },
  editNameButton: { marginLeft: 8, padding: 4 },
  bio: { fontSize: 14, color: colors.textMuted, marginBottom: spacing.md, textAlign: 'center' },
  badgesContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  classBadge: {
    backgroundColor: colors.accent,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
    marginRight: 8,
  },
  classText: { color: colors.onAccent, fontSize: 13, fontWeight: '700', textTransform: 'capitalize' },
  ageBadge: {
    backgroundColor: colors.cardSunk,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radii.pill,
  },
  ageText: { color: colors.text, fontSize: 13, fontWeight: '600' },
  // Card de estatísticas (mesmo estilo dos cards do RequisitoScreen)
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.md,
    width: '100%',
    justifyContent: 'space-around',
    marginBottom: spacing.xl,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
  },
  statBox: { alignItems: 'center', flex: 1 },
  statNumber: { fontSize: 22, fontWeight: 'bold', color: colors.text, marginTop: 4 },
  statLabel: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  statDivider: { width: 1, backgroundColor: colors.border, marginVertical: 10 },
  // Menu
  menuContainer: {
    width: '100%',
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    overflow: 'hidden',
    marginBottom: spacing.xl,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
  },
  menuDivider: { height: 1, backgroundColor: colors.border, marginHorizontal: spacing.xl },
  menuIcon: { marginRight: 15 },
  menuItemText: { flex: 1, fontSize: 15, color: colors.text },
  // Sair: vermelho de "danger" do tema
  logoutButton: {
    width: '100%',
    backgroundColor: colors.danger,
    paddingVertical: 14,
    borderRadius: radii.md,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  logoutButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  form: { width: '100%', marginBottom: spacing.lg },
  formTitulo: { color: colors.accent, fontWeight: 'bold', fontSize: 16, marginBottom: spacing.md },
  label: { color: colors.textMuted, fontSize: 13, marginBottom: 4, marginTop: spacing.sm },
  formBotoes: { flexDirection: 'row', marginTop: spacing.lg },
  btnDescartar: { flex: 1, padding: 14, borderRadius: radii.md, alignItems: 'center', borderWidth: 1, borderColor: colors.border, marginRight: 8 },
  btnDescartarText: { color: colors.textMuted, fontWeight: '600' },
  btnSalvar: { flex: 1, padding: 14, borderRadius: radii.md, alignItems: 'center', backgroundColor: colors.accent, marginLeft: 8 },
  btnSalvarText: { color: colors.onAccent, fontWeight: 'bold' },
  deleteButton: {
    width: '100%', paddingVertical: 12, borderRadius: radii.md, alignItems: 'center',
    borderWidth: 1, borderColor: colors.danger, marginBottom: spacing.xl,
  },
  deleteButtonText: { color: colors.danger, fontSize: 14, fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: spacing.xl },
  modalCard: { backgroundColor: colors.card, borderRadius: radii.lg, padding: spacing.xl },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: colors.danger, marginBottom: spacing.sm },
  modalWarn: { color: colors.text, fontSize: 13, lineHeight: 20, marginBottom: spacing.lg },
  modalLabel: { color: colors.textMuted, fontSize: 13, marginBottom: 6 },
  modalRow: { flexDirection: 'row', marginTop: spacing.sm },
  modalCancel: { flex: 1, padding: 14, borderRadius: radii.md, alignItems: 'center', backgroundColor: colors.cardSunk, marginRight: 8 },
  modalCancelText: { color: colors.text, fontWeight: '600' },
  modalConfirm: { flex: 1, padding: 14, borderRadius: radii.md, alignItems: 'center', backgroundColor: colors.danger, marginLeft: 8 },
  modalConfirmText: { color: '#fff', fontWeight: 'bold' },
});
