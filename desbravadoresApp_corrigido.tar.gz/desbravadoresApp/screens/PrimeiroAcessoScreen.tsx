import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, StatusBar, ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radii, spacing, common } from '../styles/theme';
import { apiPost } from '../services/api';
import { getUser, setUser } from '../services/auth';

// Mostrada no primeiro login de contas criadas pelo painel (professor/ADM):
// a pessoa aceita os termos e troca a senha provisória antes de usar o app.
export default function PrimeiroAcessoScreen({ navigation }) {
  const [aceitou, setAceitou] = useState(false);
  const [novaSenha, setNovaSenha] = useState('');
  const [confirmar, setConfirmar] = useState('');
  const [loading, setLoading] = useState(false);

  const handleConcluir = async () => {
    if (!aceitou) {
      Alert.alert('Erro', 'É necessário aceitar os Termos de Uso.');
      return;
    }
    if (novaSenha.length < 8) {
      Alert.alert('Erro', 'A nova senha deve ter no mínimo 8 caracteres.');
      return;
    }
    if (novaSenha !== confirmar) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }
    setLoading(true);
    try {
      await apiPost('/auth/primeiro_acesso.php', { novaSenha, aceitouTermos: true });
      // Atualiza o estado local pra refletir que já aceitou/trocou
      const u = await getUser();
      if (u) await setUser({ ...u, senhaProvisoria: false, termosAceitos: true });

      // Encaminha pelo papel
      if (u?.tipo === 'aluno') navigation.replace('Home');
      else navigation.replace('PainelProfessor');
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível concluir.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.titulo}>Primeiro acesso</Text>
        <Text style={styles.sub}>
          Para continuar, aceite os termos e defina uma nova senha pessoal.
        </Text>

        <TextInput
          style={common.input}
          placeholder="Nova senha (mínimo 8 caracteres)"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={novaSenha}
          onChangeText={setNovaSenha}
          maxLength={24}
        />
        <TextInput
          style={common.input}
          placeholder="Confirmar nova senha"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={confirmar}
          onChangeText={setConfirmar}
          maxLength={24}
        />

        <TouchableOpacity style={styles.termosRow} onPress={() => setAceitou((v) => !v)} activeOpacity={0.7}>
          <View style={[styles.checkbox, aceitou && styles.checkboxOn]}>
            {aceitou && <Text style={styles.checkMark}>✓</Text>}
          </View>
          <Text style={styles.termosText}>
            Li e aceito os{' '}
            <Text style={styles.termosLink} onPress={() => navigation.navigate('Termos')}>
              Termos de Uso e a Política de Privacidade
            </Text>.
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[common.buttonPrimary, (!aceitou || loading) && { opacity: 0.5 }]}
          onPress={handleConcluir}
          disabled={!aceitou || loading}
        >
          <Text style={common.buttonPrimaryText}>{loading ? 'Salvando...' : 'Concluir'}</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: spacing.xl, flexGrow: 1, justifyContent: 'center' },
  titulo: { fontSize: 24, fontWeight: 'bold', color: colors.accent, marginBottom: 6 },
  sub: { color: colors.textMuted, fontSize: 14, marginBottom: spacing.xl },
  termosRow: { flexDirection: 'row', alignItems: 'flex-start', marginVertical: spacing.lg },
  checkbox: {
    width: 22, height: 22, borderRadius: 5, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center', marginRight: 10, marginTop: 1,
  },
  checkboxOn: { backgroundColor: colors.accent, borderColor: colors.accent },
  checkMark: { color: colors.onAccent, fontWeight: 'bold', fontSize: 14 },
  termosText: { flex: 1, color: colors.textMuted, fontSize: 13, lineHeight: 19 },
  termosLink: { color: colors.accent, fontWeight: '600' },
});
