import React, { useState } from 'react';
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
  ScrollView,
} from 'react-native';
import { colors, radii, spacing, common } from '../styles/theme';
import { cadastrar } from '../services/auth';

export default function CriarContaScreen({ navigation }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [nascimento, setNascimento] = useState(''); // exibido como DD/MM/AAAA
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [aceitouTermos, setAceitouTermos] = useState(false);
  const [loading, setLoading] = useState(false);

  // Máscara DD/MM/AAAA enquanto digita (só números, barras automáticas)
  const onChangeNascimento = (txt: string) => {
    const nums = txt.replace(/\D/g, '').slice(0, 8);
    let out = nums;
    if (nums.length > 4) out = `${nums.slice(0, 2)}/${nums.slice(2, 4)}/${nums.slice(4)}`;
    else if (nums.length > 2) out = `${nums.slice(0, 2)}/${nums.slice(2)}`;
    setNascimento(out);
  };

  // Converte DD/MM/AAAA -> YYYY-MM-DD; retorna '' se inválida
  const nascimentoParaISO = (s: string): string => {
    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!m) return '';
    const [_, dd, mm, aaaa] = m;
    const d = new Date(`${aaaa}-${mm}-${dd}T00:00:00`);
    // valida que a data existe de verdade (ex.: 31/02 não passa)
    if (
      d.getFullYear() !== +aaaa ||
      d.getMonth() + 1 !== +mm ||
      d.getDate() !== +dd ||
      d > new Date()
    ) return '';
    return `${aaaa}-${mm}-${dd}`;
  };

  const handleCriarConta = async () => {
    if (!nome || nome.length < 3) {
      Alert.alert('Erro', 'O nome deve ter no mínimo 3 caracteres.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erro', 'Por favor, insira um e-mail válido.');
      return;
    }
    const nascISO = nascimentoParaISO(nascimento);
    if (!nascISO) {
      Alert.alert('Erro', 'Informe uma data de nascimento válida (DD/MM/AAAA).');
      return;
    }
    if (!senha || senha.length < 8) {
      Alert.alert('Erro', 'A senha deve ter no mínimo 8 caracteres.');
      return;
    }
    if (senha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }
    if (!aceitouTermos) {
      Alert.alert('Erro', 'É necessário aceitar os Termos de Uso para criar a conta.');
      return;
    }
    setLoading(true);
    try {
      await cadastrar(nome.trim(), email.trim(), senha, aceitouTermos, nascISO);
      navigation.navigate('Requisito');
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível criar a conta.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <View style={styles.card}>
        <Text style={styles.titulo}>Criar Conta</Text>
        <Text style={styles.subtitulo}>Preencha os dados para se cadastrar</Text>

        <TextInput
          style={styles.input}
          placeholder="Nome"
          placeholderTextColor={colors.placeholder}
          value={nome}
          onChangeText={setNome}
          maxLength={144}
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor={colors.placeholder}
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
          maxLength={244}
        />
        <TextInput
          style={styles.input}
          placeholder="Data de nascimento (DD/MM/AAAA)"
          placeholderTextColor={colors.placeholder}
          keyboardType="number-pad"
          value={nascimento}
          onChangeText={onChangeNascimento}
          maxLength={10}
        />
        <TextInput
          style={styles.input}
          placeholder="Senha (mínimo 8 caracteres)"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
          maxLength={24}
        />
        <TextInput
          style={styles.input}
          placeholder="Confirmar Senha"
          placeholderTextColor={colors.placeholder}
          secureTextEntry
          value={confirmarSenha}
          onChangeText={setConfirmarSenha}
          maxLength={24}
        />

        {/* Checkbox de aceite dos Termos + LGPD (obrigatório) */}
        <TouchableOpacity
          style={styles.termosRow}
          onPress={() => setAceitouTermos((v) => !v)}
          activeOpacity={0.7}
        >
          <View style={[styles.checkbox, aceitouTermos && styles.checkboxOn]}>
            {aceitouTermos && <Text style={styles.checkMark}>✓</Text>}
          </View>
          <Text style={styles.termosText}>
            Estou ciente e consinto com a coleta dos meus dados, conforme o{' '}
            <Text
              style={styles.termosLink}
              onPress={() => navigation.navigate('Consentimento')}
            >
              Consentimento de Dados
            </Text>
            .
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.botao, (!aceitouTermos || loading) && { opacity: 0.5 }]}
          onPress={handleCriarConta}
          disabled={!aceitouTermos || loading}
        >
          <Text style={styles.textoBotao}>{loading ? 'Cadastrando...' : 'Cadastrar'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.link}>Já tenho conta — Fazer login</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scrollContent: { flexGrow: 1, justifyContent: 'center', padding: spacing.xl },
  card: {
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    padding: spacing.xl,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
    elevation: 5,
  },
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    color: colors.accent,
    marginBottom: 5,
  },
  subtitulo: {
    fontSize: 14,
    textAlign: 'center',
    color: colors.textMuted,
    marginBottom: spacing.xl,
  },
  input: common.input,
  botao: { ...common.buttonPrimary, marginTop: 5 },
  textoBotao: common.buttonPrimaryText,
  termosRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: spacing.lg, paddingRight: 4 },
  checkbox: {
    width: 22, height: 22, borderRadius: 5, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center', marginRight: 10, marginTop: 1,
  },
  checkboxOn: { backgroundColor: colors.accent, borderColor: colors.accent },
  checkMark: { color: colors.onAccent, fontWeight: 'bold', fontSize: 14 },
  termosText: { flex: 1, color: colors.textMuted, fontSize: 13, lineHeight: 19 },
  termosLink: { color: colors.accent, fontWeight: '600' },
  link: { textAlign: 'center', color: colors.accent, marginTop: 15, fontWeight: '500' },
});
