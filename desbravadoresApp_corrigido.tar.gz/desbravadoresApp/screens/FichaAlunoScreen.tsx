import React, { useState, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, StatusBar, ScrollView, ActivityIndicator, Alert,
  Image, Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { colors, radii, spacing } from '../styles/theme';
import { fichaAluno, avancarClasse, retrocederClasse, requisitosAluno } from '../services/professor';
import { CLASSES_REQUISITOS } from '../data/classes';

export default function FichaAlunoScreen({ route, navigation }) {
  const { id, nome } = route.params || {};
  const [ficha, setFicha] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [acao, setAcao] = useState(false);

  // --- Evidências ---
  const [classeSel, setClasseSel] = useState<string | null>(null);
  const [marcados, setMarcados] = useState<{ [i: string]: { foto: string | null } }>({});
  const [carregandoReq, setCarregandoReq] = useState(false);
  const [fotoZoom, setFotoZoom] = useState<string | null>(null);
  const [exportando, setExportando] = useState(false);

  // Exporta a ficha completa do aluno em PDF (lado professor).
  const exportarPDF = async () => {
    if (!ficha) return;
    setExportando(true);
    try {
      const a = ficha.aluno;
      const ordem: string[] = ficha.ordemClasses || [];
      const concluidasSet = new Set((ficha.concluidas || []).map((c: any) => c.classe));
      const hoje = new Date().toLocaleDateString('pt-BR');

      // Busca os requisitos marcados de cada classe (pra contar concluídos)
      const blocos: string[] = [];
      for (const classe of ordem) {
        const reqs = CLASSES_REQUISITOS[classe] || [];
        let marc: any = {};
        try { marc = await requisitosAluno(a.id, classe); } catch {}
        const feitos = Object.keys(marc).length;
        const concluida = concluidasSet.has(classe);
        const ativa = classe === a.classe;
        const status = concluida ? 'CONCLUÍDA' : ativa ? 'EM ANDAMENTO' : 'NÃO INICIADA';
        const cor = concluida ? '#22c55e' : ativa ? '#facc15' : '#e2e8f0';
        const corTxt = ativa && !concluida ? '#0f172a' : concluida ? '#fff' : '#64748b';

        const linhas = reqs.map((req, i) => {
          const m = marc[String(i)];
          const ok = !!m;
          const temFoto = m && m.foto;
          const selo = ok
            ? `<span class="ok">${temFoto ? 'COM FOTO' : 'CONCLUÍDO'}</span>`
            : '<span class="pend">PENDENTE</span>';
          return `<tr><td class="sel">${selo}</td><td>${req}</td></tr>`;
        }).join('');

        blocos.push(`
          <div class="classe">
            <div class="ch">
              <h2>${classe}</h2>
              <span class="badge" style="background:${cor};color:${corTxt}">${status}</span>
            </div>
            <p class="cnt">${feitos} de ${reqs.length} requisitos marcados</p>
            <table>${linhas}</table>
          </div>`);
      }

      const histHtml = (ficha.concluidas || []).length
        ? ficha.concluidas.map((c: any) =>
            `<li><b>${c.classe}</b> — concluída por ${c.concluido_por_nome}${c.concluido_em ? ' em ' + String(c.concluido_em).slice(0,10).split('-').reverse().join('/') : ''}</li>`
          ).join('')
        : '<li>Nenhuma classe concluída ainda.</li>';

      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
        * { font-family: Helvetica, Arial, sans-serif; }
        body { padding: 32px; color: #1e293b; }
        .head { border-bottom: 3px solid #facc15; padding-bottom: 16px; margin-bottom: 16px; }
        h1 { color: #0f172a; margin: 0 0 4px; font-size: 24px; }
        .sub { color: #64748b; font-size: 13px; margin: 2px 0; }
        .hist { background: #f8fafc; border-radius: 10px; padding: 16px 16px 16px 32px; margin: 16px 0; }
        .hist li { font-size: 13px; margin: 4px 0; }
        .classe { margin: 18px 0; page-break-inside: avoid; }
        .ch { display: flex; align-items: center; gap: 10px; }
        h2 { color: #0f172a; font-size: 18px; margin: 0; }
        .badge { padding: 3px 10px; border-radius: 6px; font-size: 11px; font-weight: bold; }
        .cnt { color: #64748b; font-size: 12px; margin: 4px 0 6px; }
        table { width: 100%; border-collapse: collapse; }
        td { padding: 8px; border-bottom: 1px solid #e2e8f0; font-size: 12px; vertical-align: top; }
        .sel { width: 100px; }
        .ok { background: #22c55e; color: #fff; padding: 2px 7px; border-radius: 5px; font-size: 10px; font-weight: bold; }
        .pend { background: #e2e8f0; color: #64748b; padding: 2px 7px; border-radius: 5px; font-size: 10px; font-weight: bold; }
        .foot { margin-top: 24px; color: #94a3b8; font-size: 11px; text-align: center; }
      </style></head><body>
        <div class="head">
          <h1>Ficha do Desbravador</h1>
          <p class="sub">Nome: ${a.nome}</p>
          <p class="sub">E-mail: ${a.email}${a.idade != null ? ' • Idade: ' + a.idade + ' anos' : ''}</p>
          <p class="sub">Classe atual: ${a.classe} • Emitido em ${hoje}</p>
        </div>
        <h3>Histórico de classes concluídas</h3>
        <ul class="hist">${histHtml}</ul>
        <h3>Detalhamento por classe</h3>
        ${blocos.join('')}
        <p class="foot">Clube de Desbravadores • Documento gerado pelo professor</p>
      </body></html>`;

      const { uri } = await Print.printToFileAsync({ html });
      await Sharing.shareAsync(uri);
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível gerar o PDF.');
    } finally {
      setExportando(false);
    }
  };

  // Carrega os requisitos marcados de uma classe (evidências)
  const abrirClasse = async (classe: string) => {
    if (classeSel === classe) { setClasseSel(null); return; } // toca de novo = fecha
    setClasseSel(classe);
    setCarregandoReq(true);
    try {
      setMarcados(await requisitosAluno(id, classe));
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha ao carregar evidências.');
      setMarcados({});
    } finally {
      setCarregandoReq(false);
    }
  };

  const carregar = useCallback(async () => {
    setLoading(true);
    try {
      setFicha(await fichaAluno(id));
      setClasseSel(null); // fecha evidências abertas (classe pode ter mudado)
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Não foi possível carregar a ficha.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useFocusEffect(useCallback(() => { carregar(); }, [carregar]));

  const confirmarAvancar = () => {
    const prox = ficha?.proximaClasse;
    if (!prox) {
      Alert.alert('Aviso', 'O aluno já está na última classe.');
      return;
    }
    Alert.alert(
      'Avançar classe',
      `Concluir a classe ${ficha.aluno.classe} e mover ${ficha.aluno.nome} para ${prox}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Avançar', onPress: avancar },
      ]
    );
  };

  const avancar = async () => {
    setAcao(true);
    try {
      const r = await avancarClasse(id);
      Alert.alert('Pronto', r.message);
      carregar();
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha ao avançar.');
    } finally {
      setAcao(false);
    }
  };

  const confirmarRetroceder = () => {
    Alert.alert(
      'Retroceder classe',
      `Voltar ${ficha.aluno.nome} para a classe anterior? Isso desfaz a conclusão dela.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Retroceder', style: 'destructive', onPress: retroceder },
      ]
    );
  };

  const retroceder = async () => {
    setAcao(true);
    try {
      const r = await retrocederClasse(id);
      Alert.alert('Pronto', r.message);
      carregar();
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha ao retroceder.');
    } finally {
      setAcao(false);
    }
  };

  if (loading || !ficha) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
        <ActivityIndicator color={colors.accent} style={{ marginTop: 60 }} />
      </SafeAreaView>
    );
  }

  const a = ficha.aluno;
  const concluidasSet = new Set((ficha.concluidas || []).map((c: any) => c.classe));

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={{ padding: spacing.xl }}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.voltar}>‹ Voltar</Text>
        </TouchableOpacity>

        {/* Cabeçalho do aluno */}
        <View style={styles.head}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{a.nome[0]?.toUpperCase()}</Text></View>
          <Text style={styles.nome}>{a.nome}</Text>
          <Text style={styles.email}>{a.email}</Text>
          <View style={styles.badges}>
            <View style={styles.badge}><Text style={styles.badgeText}>Classe: {a.classe}</Text></View>
            {a.idade != null && <View style={styles.badgeAlt}><Text style={styles.badgeAltText}>{a.idade} anos</Text></View>}
          </View>
        </View>

        {/* Ação principal: avançar de classe */}
        <View style={styles.acaoCard}>
          <Text style={styles.acaoTitulo}>Progresso de classe</Text>
          <Text style={styles.acaoInfo}>
            Classe atual: <Text style={{ color: colors.accent, fontWeight: 'bold' }}>{a.classe}</Text>
          </Text>
          <Text style={styles.acaoInfo}>
            {ficha.proximaClasse
              ? `Próxima: ${ficha.proximaClasse}`
              : 'Última classe alcançada.'}
          </Text>

          <TouchableOpacity
            style={[styles.btnAvancar, (!ficha.proximaClasse || acao) && { opacity: 0.5 }]}
            onPress={confirmarAvancar}
            disabled={!ficha.proximaClasse || acao}
          >
            <Text style={styles.btnAvancarText}>
              {ficha.proximaClasse ? `Avançar para ${ficha.proximaClasse}` : 'Sem próxima classe'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btnRetroceder} onPress={confirmarRetroceder} disabled={acao}>
            <Text style={styles.btnRetrocederText}>Retroceder uma classe</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.btnPdf, exportando && { opacity: 0.6 }]}
            onPress={exportarPDF}
            disabled={exportando}
          >
            <Text style={styles.btnPdfText}>{exportando ? 'Gerando PDF...' : '📄 Exportar ficha em PDF'}</Text>
          </TouchableOpacity>
        </View>

        {/* Linha das 6 classes — toque pra ver as evidências daquela classe */}
        <Text style={styles.secTitulo}>Classes e evidências</Text>
        <Text style={styles.secDica}>Toque numa classe para verificar os requisitos enviados pelo aluno.</Text>
        {(ficha.ordemClasses || []).map((classe: string) => {
          const concluida = concluidasSet.has(classe);
          const ativa = classe === a.classe;
          const aberta = classeSel === classe;
          const reqs = CLASSES_REQUISITOS[classe] || [];
          return (
            <View key={classe} style={styles.classeBloco}>
              <TouchableOpacity style={styles.classeRow} onPress={() => abrirClasse(classe)} activeOpacity={0.8}>
                <Text style={styles.classeNome}>{aberta ? '▾ ' : '▸ '}{classe}</Text>
                <Text style={[
                  styles.classeStatus,
                  concluida && { color: colors.success },
                  ativa && { color: colors.accent },
                ]}>
                  {concluida ? '✓ concluída' : ativa ? '• em andamento' : 'não iniciada'}
                </Text>
              </TouchableOpacity>

              {aberta && (
                <View style={styles.evidencias}>
                  {carregandoReq ? (
                    <ActivityIndicator color={colors.accent} style={{ marginVertical: 16 }} />
                  ) : reqs.length === 0 ? (
                    <Text style={styles.vazio}>Sem requisitos cadastrados.</Text>
                  ) : (
                    reqs.map((texto, idx) => {
                      const m = marcados[String(idx)];
                      const temFoto = m && m.foto;
                      const marcado = !!m;
                      return (
                        <View key={idx} style={styles.reqItem}>
                          <View style={styles.reqTopo}>
                            <Text style={styles.reqStatus}>
                              {temFoto ? '📷' : marcado ? '✓' : '⬜'}
                            </Text>
                            <Text style={styles.reqTexto}>{texto}</Text>
                          </View>
                          {temFoto ? (
                            <TouchableOpacity onPress={() => setFotoZoom(m!.foto)}>
                              <Image source={{ uri: m!.foto! }} style={styles.thumb} />
                              <Text style={styles.verFoto}>Toque para ampliar a evidência</Text>
                            </TouchableOpacity>
                          ) : marcado ? (
                            <Text style={styles.semFoto}>Marcado pelo aluno (sem foto).</Text>
                          ) : (
                            <Text style={styles.naoFeito}>Ainda não enviado.</Text>
                          )}
                        </View>
                      );
                    })
                  )}
                </View>
              )}
            </View>
          );
        })}

        {/* Histórico */}
        <Text style={styles.secTitulo}>Histórico</Text>
        {(ficha.concluidas || []).length === 0 ? (
          <Text style={styles.vazio}>Nenhuma classe concluída ainda.</Text>
        ) : (
          ficha.concluidas.map((c: any, i: number) => (
            <View key={i} style={styles.histItem}>
              <Text style={styles.histClasse}>{c.classe}</Text>
              <Text style={styles.histInfo}>
                Concluída por {c.concluido_por_nome}
                {c.concluido_em ? ` em ${String(c.concluido_em).slice(0, 10).split('-').reverse().join('/')}` : ''}
              </Text>
            </View>
          ))
        )}
      </ScrollView>

      {/* Modal de zoom da evidência */}
      <Modal visible={!!fotoZoom} transparent animationType="fade" onRequestClose={() => setFotoZoom(null)}>
        <TouchableOpacity style={styles.zoomOverlay} activeOpacity={1} onPress={() => setFotoZoom(null)}>
          {fotoZoom && <Image source={{ uri: fotoZoom }} style={styles.zoomImg} resizeMode="contain" />}
          <Text style={styles.zoomFechar}>Toque para fechar</Text>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  voltar: { color: colors.accent, fontSize: 16, marginBottom: spacing.md },
  head: { alignItems: 'center', marginBottom: spacing.xl },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.sm },
  avatarText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 32 },
  nome: { color: colors.text, fontSize: 22, fontWeight: 'bold' },
  email: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  badges: { flexDirection: 'row', marginTop: spacing.md },
  badge: { backgroundColor: colors.accent, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radii.pill, marginRight: 8 },
  badgeText: { color: colors.onAccent, fontWeight: '700', fontSize: 13 },
  badgeAlt: { backgroundColor: colors.cardSunk, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radii.pill },
  badgeAltText: { color: colors.text, fontWeight: '600', fontSize: 13 },
  acaoCard: { backgroundColor: colors.card, borderRadius: radii.lg, padding: spacing.lg, borderLeftWidth: 5, borderLeftColor: colors.accent, marginBottom: spacing.xl },
  acaoTitulo: { color: colors.accent, fontWeight: 'bold', fontSize: 16, marginBottom: spacing.sm },
  acaoInfo: { color: colors.text, fontSize: 14, marginBottom: 2 },
  btnAvancar: { backgroundColor: colors.accent, padding: 14, borderRadius: radii.md, alignItems: 'center', marginTop: spacing.md },
  btnAvancarText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 15 },
  btnRetroceder: { padding: 12, borderRadius: radii.md, alignItems: 'center', marginTop: spacing.sm, borderWidth: 1, borderColor: colors.border },
  btnRetrocederText: { color: colors.textMuted, fontWeight: '600' },
  btnPdf: { padding: 12, borderRadius: radii.md, alignItems: 'center', marginTop: spacing.sm, backgroundColor: colors.cardSunk },
  btnPdfText: { color: colors.text, fontWeight: '600' },
  secTitulo: { color: colors.accent, fontWeight: 'bold', fontSize: 15, marginTop: spacing.md, marginBottom: spacing.sm },
  secDica: { color: colors.textMuted, fontSize: 12, marginBottom: spacing.sm },
  classeBloco: { marginBottom: 6 },
  classeRow: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: colors.card, padding: spacing.md, borderRadius: radii.sm },
  classeNome: { color: colors.text, fontSize: 14, fontWeight: '600' },
  classeStatus: { color: colors.textMuted, fontSize: 13 },
  evidencias: { backgroundColor: colors.cardSunk, borderRadius: radii.sm, padding: spacing.md, marginTop: 4 },
  reqItem: { marginBottom: spacing.md, paddingBottom: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border },
  reqTopo: { flexDirection: 'row' },
  reqStatus: { fontSize: 15, marginRight: 8 },
  reqTexto: { flex: 1, color: colors.text, fontSize: 13, lineHeight: 19 },
  thumb: { width: '100%', height: 200, borderRadius: radii.sm, marginTop: 8, backgroundColor: colors.bg },
  verFoto: { color: colors.accent, fontSize: 11, marginTop: 4, textAlign: 'center' },
  semFoto: { color: colors.textMuted, fontSize: 12, fontStyle: 'italic', marginTop: 6, marginLeft: 23 },
  naoFeito: { color: colors.textMuted, fontSize: 12, marginTop: 6, marginLeft: 23 },
  zoomOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.92)', justifyContent: 'center', alignItems: 'center', padding: spacing.lg },
  zoomImg: { width: '100%', height: '80%' },
  zoomFechar: { color: '#fff', marginTop: spacing.lg, fontSize: 14 },
  histItem: { backgroundColor: colors.card, padding: spacing.md, borderRadius: radii.sm, marginBottom: 6, borderLeftWidth: 3, borderLeftColor: colors.success },
  histClasse: { color: colors.text, fontWeight: '700', fontSize: 14 },
  histInfo: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  vazio: { color: colors.textMuted, fontSize: 13 },
});
