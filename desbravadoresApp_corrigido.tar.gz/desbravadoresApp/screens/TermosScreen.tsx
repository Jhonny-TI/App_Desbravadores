import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, radii, spacing } from '../styles/theme';

// ATENÇÃO: texto PROVISÓRIO. Antes de publicar, substitua por Termos de Uso
// e Política de Privacidade reais (LGPD). Recomendo apoio jurídico.
export default function TermosScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.titulo}>Termos de Uso e Política de Privacidade</Text>

        <View style={styles.aviso}>
          <Text style={styles.avisoText}>
            [TEXTO PROVISÓRIO — substituir antes de publicar o aplicativo.]
          </Text>
        </View>

        <Text style={styles.h}>1. Coleta de dados</Text>
        <Text style={styles.p}>
          O aplicativo coleta nome, e-mail e o progresso nas classes de Desbravadores,
          incluindo fotos enviadas como evidência das atividades.
        </Text>

        <Text style={styles.h}>2. Uso dos dados</Text>
        <Text style={styles.p}>
          Os dados são usados exclusivamente para acompanhar o progresso do desbravador
          e permitir que líderes e professores validem as atividades concluídas.
        </Text>

        <Text style={styles.h}>3. Seus direitos (LGPD)</Text>
        <Text style={styles.p}>
          Você pode solicitar a exclusão permanente da sua conta e de todos os seus dados
          a qualquer momento, pela tela de Configurações do seu perfil.
        </Text>

        <Text style={styles.h}>4. Contato</Text>
        <Text style={styles.p}>
          Dúvidas sobre privacidade devem ser encaminhadas à direção do clube.
        </Text>

        <TouchableOpacity style={styles.botao} onPress={() => navigation.goBack()}>
          <Text style={styles.botaoText}>Voltar</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  content: { padding: spacing.xl, paddingBottom: 40 },
  titulo: { fontSize: 22, fontWeight: 'bold', color: colors.accent, marginBottom: spacing.lg },
  aviso: {
    backgroundColor: colors.cardSunk, borderLeftWidth: 4, borderLeftColor: colors.accent,
    padding: spacing.md, borderRadius: radii.sm, marginBottom: spacing.lg,
  },
  avisoText: { color: colors.text, fontSize: 13, fontStyle: 'italic' },
  h: { color: colors.accent, fontWeight: '700', fontSize: 15, marginTop: spacing.md, marginBottom: 4 },
  p: { color: colors.text, fontSize: 14, lineHeight: 21 },
  botao: {
    backgroundColor: colors.accent, padding: 14, borderRadius: radii.md,
    alignItems: 'center', marginTop: spacing.xl,
  },
  botaoText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 16 },
});
