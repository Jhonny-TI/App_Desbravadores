import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
} from 'react-native';
import { recuperarSenha } from '../services/auth';
import { colors, radii, spacing, common } from '../styles/theme';

export default function RecuperarEmailScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSendEmail = async () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erro', 'Por favor, insira um e-mail válido.');
      return;
    }
    setLoading(true);
    try {
      const msg = await recuperarSenha(email.trim());
      Alert.alert('Sucesso', msg);
      navigation.navigate('Login');
    } catch (e: any) {
      Alert.alert('Erro', e.message || 'Falha na conexão com o servidor.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <View style={styles.card}>
        <Text style={styles.title}>Recuperar Senha</Text>
        <Text style={styles.subtitle}>
          Digite seu e-mail para receber o link de redefinição de senha
        </Text>

        <TextInput
          style={styles.input}
          placeholder="E-mail"
          placeholderTextColor={colors.placeholder}
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleSendEmail}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? 'Enviando...' : 'Enviar E-mail'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.link}>Voltar para login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg, justifyContent: 'center', padding: spacing.xl },
  card: {
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    padding: spacing.xl,
    borderLeftWidth: 5,
    borderLeftColor: colors.accent,
    elevation: 5,
  },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', color: colors.accent, marginBottom: 8 },
  subtitle: { fontSize: 14, textAlign: 'center', color: colors.textMuted, marginBottom: spacing.xl },
  input: common.input,
  button: common.buttonPrimary,
  buttonDisabled: { opacity: 0.6 },
  buttonText: common.buttonPrimaryText,
  link: { textAlign: 'center', color: colors.accent, marginTop: 15, fontWeight: '500' },
});
