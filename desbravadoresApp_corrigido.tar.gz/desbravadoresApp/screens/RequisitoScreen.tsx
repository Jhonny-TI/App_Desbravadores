import React, { useState, useEffect } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { useAuth } from '../hooks/useAuth';
import { listarRequisitos, marcarRequisito, enviarFoto, removerFoto } from '../services/aluno';

const Stack = createNativeStackNavigator();

// --- DADOS DAS CLASSES ---
import { CLASSES_REQUISITOS as data } from '../data/classes';

// --- TELA INICIAL (lista de classes, interna ao navigator de Requisito) ---
function ListaClasses({ navigation }) {
  const classes = Object.keys(data);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Classes dos Desbravadores</Text>
      {classes.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={styles.cardHome}
          onPress={() => navigation.navigate('Classe', { name: item })}
        >
          <Text style={styles.cardTextHome}>{item}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

// --- TELA DA CLASSE ---
function ClassScreen({ route, navigation }) {
  const { name } = route.params || {};
  const { user } = useAuth();
  const [checkedItems, setCheckedItems] = useState({});

  // Modo leitura quando: ninguém logado, OU usuário logado mas a classe
  // mostrada não é a classe dele (ex.: aluno Amigo espiando Pioneiro).
  // Professor sempre vê em modo leitura por enquanto (será revisto depois).
  const readOnly = !user || user.tipo !== 'aluno' || user.classe !== name;

  useEffect(() => {
    loadData();
  }, [name]);

  // Carrega do backend os requisitos marcados desta classe.
  // Mantém o formato do estado: checkedItems[indice] = true | "url-da-foto".
  const loadData = async () => {
    if (!user) { setCheckedItems({}); return; } // deslogado: nada a carregar
    try {
      const marcados = await listarRequisitos(name);
      const estado = {};
      Object.keys(marcados).forEach((idx) => {
        const foto = marcados[idx]?.foto;
        estado[idx] = foto ? foto : true; // string se tem foto, true se só marcado
      });
      setCheckedItems(estado);
    } catch (error) {
      console.log('Erro ao carregar requisitos:', error);
    }
  };

  // Marca/desmarca um requisito (otimista: atualiza a tela e sincroniza com o servidor)
  const toggleCheck = async (index) => {
    if (readOnly) return;
    const updated = { ...checkedItems };
    const novoMarcado = !updated[index];
    if (novoMarcado) updated[index] = true; else delete updated[index];
    setCheckedItems(updated);
    try {
      await marcarRequisito(name, index, novoMarcado);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível salvar. Tente de novo.');
      loadData(); // reverte pro estado real do servidor
    }
  };

  // Envia foto de evidência (marca automaticamente)
  const savePhotoProgress = async (index, imageUri) => {
    try {
      const fotoUrl = await enviarFoto(name, index, imageUri);
      setCheckedItems((prev) => ({ ...prev, [index]: fotoUrl }));
    } catch (error) {
      Alert.alert('Erro', 'Falha ao enviar a foto.');
    }
  };

  // Lixeira: remove só a foto, mantém o requisito marcado
  const removeRequirement = async (index) => {
    if (readOnly) return;
    try {
      await removerFoto(name, index);
      setCheckedItems((prev) => ({ ...prev, [index]: true })); // continua marcado, sem foto
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível remover a foto.');
    }
  };

  const handleTakePicture = async (index) => {
    const { granted } = await ImagePicker.requestCameraPermissionsAsync();
    if (!granted) return Alert.alert('Aviso', 'Permissão de câmera negada');

    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, quality: 0.5 });
    if (!result.canceled) savePhotoProgress(index, result.assets[0].uri);
  };

  const handlePickImage = async (index) => {
    const result = await ImagePicker.launchImageLibraryAsync({ allowsEditing: true, quality: 0.5 });
    if (!result.canceled) savePhotoProgress(index, result.assets[0].uri);
  };

  const exportPDF = async () => {
    const total = data[name]?.length || 0;
    const feitos = data[name].filter((_, i) => checkedItems[i]).length;
    const pct = total > 0 ? Math.round((feitos / total) * 100) : 0;
    const hoje = new Date().toLocaleDateString('pt-BR');

    const linhas = data[name].map((req, index) => {
      const concluido = !!checkedItems[index];
      const selo = concluido
        ? '<span class="ok">CONCLUÍDO</span>'
        : '<span class="pend">PENDENTE</span>';
      return `<tr class="${concluido ? 'rOk' : ''}">
        <td class="sel">${selo}</td>
        <td class="txt">${req}</td>
      </tr>`;
    }).join('');

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
      <style>
        * { font-family: Helvetica, Arial, sans-serif; }
        body { padding: 32px; color: #1e293b; }
        .head { border-bottom: 3px solid #facc15; padding-bottom: 16px; margin-bottom: 8px; }
        h1 { color: #0f172a; margin: 0 0 4px; font-size: 24px; }
        .sub { color: #64748b; font-size: 13px; margin: 2px 0; }
        .resumo { background: #f8fafc; border-radius: 10px; padding: 16px; margin: 20px 0; }
        .resumo b { color: #0f172a; font-size: 18px; }
        .barra { height: 12px; background: #e2e8f0; border-radius: 6px; overflow: hidden; margin-top: 8px; }
        .fill { height: 100%; background: #22c55e; width: ${pct}%; }
        table { width: 100%; border-collapse: collapse; margin-top: 8px; }
        td { padding: 10px 8px; border-bottom: 1px solid #e2e8f0; vertical-align: top; font-size: 13px; }
        .sel { width: 110px; }
        .rOk { background: #f0fdf4; }
        .ok { background: #22c55e; color: #fff; padding: 3px 8px; border-radius: 5px; font-size: 11px; font-weight: bold; }
        .pend { background: #e2e8f0; color: #64748b; padding: 3px 8px; border-radius: 5px; font-size: 11px; font-weight: bold; }
        .foot { margin-top: 24px; color: #94a3b8; font-size: 11px; text-align: center; }
      </style></head><body>
      <div class="head">
        <h1>Ficha de Progresso — Classe ${name}</h1>
        <p class="sub">Desbravador(a): ${user?.nome || '—'}</p>
        <p class="sub">Emitido em ${hoje}</p>
      </div>
      <div class="resumo">
        <b>${feitos} de ${total} requisitos concluídos (${pct}%)</b>
        <div class="barra"><div class="fill"></div></div>
      </div>
      <table>${linhas}</table>
      <p class="foot">Clube de Desbravadores • Documento gerado pelo aplicativo</p>
      </body></html>`;

    const { uri } = await Print.printToFileAsync({ html });
    await Sharing.shareAsync(uri);
  };

  const totalItems = data[name]?.length || 0;
  const checkedCount = Object.keys(checkedItems).length;
  const progress = totalItems > 0 ? (checkedCount / totalItems) * 100 : 0;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{name}</Text>

      {readOnly && (
        <View style={styles.readonlyBanner}>
          <Text style={styles.readonlyBannerText}>
            {!user
              ? 'Modo consulta — faça login para registrar seu progresso.'
              : user.tipo === 'professor'
              ? 'Visualização do professor (somente leitura).'
              : `Você está espiando a classe ${name}. Sua classe atual é ${user.classe}.`}
          </Text>
        </View>
      )}

      {!readOnly && (
        <>
          <TouchableOpacity style={styles.btnExport} onPress={exportPDF}>
            <Text style={styles.btnExportText}>📥 Exportar Relatório PDF</Text>
          </TouchableOpacity>

          <Text style={styles.progressText}>Progresso: {progress.toFixed(0)}%</Text>
          <View style={styles.progressBarBackground}>
            <View style={[styles.progressBarFill, { width: `${progress}%` }]} />
          </View>
        </>
      )}

      {data[name]?.map((req, index) => (
        <View key={index} style={styles.cardReq}>
          {readOnly ? (
            // Modo leitura: só o texto, sem checkbox interativa.
            <Text style={styles.cardText}>• {req}</Text>
          ) : (
            <>
              <TouchableOpacity onPress={() => toggleCheck(index)}>
                <Text style={styles.cardText}>
                  {checkedItems[index] ? '✅' : '⬜'} {req}
                </Text>
              </TouchableOpacity>

              <View style={styles.photoArea}>
                {typeof checkedItems[index] === 'string' ? (
                  <TouchableOpacity onPress={() => removeRequirement(index)}>
                    <Image source={{ uri: checkedItems[index] }} style={styles.thumbnail} />
                    <Text style={styles.removeText}>Toque na imagem para remover tudo</Text>
                  </TouchableOpacity>
                ) : (
                  <View style={styles.row}>
                    <TouchableOpacity style={styles.btnIcon} onPress={() => handleTakePicture(index)}>
                      <Text style={styles.btnIconText}>📷 Foto</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.btnIcon} onPress={() => handlePickImage(index)}>
                      <Text style={styles.btnIconText}>🖼️ Galeria</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </>
          )}
        </View>
      ))}

      {/* Botão de voltar estilizado no fim da página */}
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backButtonText}>Voltar para Classes</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// --- NAVIGATOR INTERNO ---
// Este é um navigator ANINHADO: ele já roda dentro do NavigationContainer do App.js.
// Por isso NÃO pode ter outro NavigationContainer aqui (causaria erro de containers aninhados).
export default function RequisitoScreen() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#0f172a' }, headerTintColor: '#fff' }}>
      <Stack.Screen name="ListaClasses" component={ListaClasses} options={{ title: 'Menu Principal' }} />
      <Stack.Screen name="Classe" component={ClassScreen} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a', padding: 20 },
  title: { fontSize: 24, color: '#facc15', fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  // Home
  cardHome: { backgroundColor: '#1e293b', padding: 20, borderRadius: 15, marginBottom: 12, borderLeftWidth: 5, borderLeftColor: '#facc15' },
  cardTextHome: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  // Requisitos
  cardReq: { backgroundColor: '#1e293b', padding: 15, borderRadius: 15, marginBottom: 15 },
  cardText: { color: '#fff', fontSize: 15, lineHeight: 22 },
  progressText: { color: '#fff', textAlign: 'center', marginBottom: 10 },
  progressBarBackground: { height: 12, backgroundColor: '#334155', borderRadius: 6, marginBottom: 20, overflow: 'hidden' },
  progressBarFill: { height: '100%', backgroundColor: '#22c55e' },
  // Fotos
  photoArea: { marginTop: 10, alignItems: 'center' },
  row: { flexDirection: 'row', gap: 10 },
  btnIcon: { backgroundColor: '#334155', padding: 8, borderRadius: 8 },
  btnIconText: { color: '#fff', fontSize: 12 },
  thumbnail: { width: 120, height: 90, borderRadius: 8, borderWidth: 2, borderColor: '#22c55e' },
  removeText: { color: '#ef4444', fontSize: 10, marginTop: 5, textAlign: 'center' },
  // Exportar
  btnExport: { backgroundColor: '#facc15', padding: 12, borderRadius: 10, marginBottom: 20, alignItems: 'center' },
  btnExportText: { color: '#0f172a', fontWeight: 'bold' },
  // Botão Voltar
  backButton: { backgroundColor: '#facc15', padding: 15, borderRadius: 15, marginTop: 20, marginBottom: 40, alignItems: 'center' },
  backButtonText: { color: '#0f172a', fontSize: 16, fontWeight: 'bold' },
  // Banner de modo consulta
  readonlyBanner: {
    backgroundColor: '#334155',
    borderLeftWidth: 4,
    borderLeftColor: '#facc15',
    padding: 12,
    borderRadius: 10,
    marginBottom: 20,
  },
  readonlyBannerText: { color: '#facc15', fontSize: 13, fontWeight: '600' },
});