import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar, FlatList, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radii, spacing } from '../styles/theme';
import { logout, getUser } from '../services/auth';
import { listarAlunos, AlunoResumo } from '../services/professor';

export default function PainelProfessorScreen({ navigation }) {
  const [nomeProf, setNomeProf] = useState('');
  const [busca, setBusca] = useState('');
  const [alunos, setAlunos] = useState<AlunoResumo[]>([]);
  const [loading, setLoading] = useState(true);

  const carregar = useCallback(async (texto = '') => {
    setLoading(true);
    try {
      const lista = await listarAlunos(texto);
      setAlunos(lista);
    } catch (e) {
      setAlunos([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        const u = await getUser();
        setNomeProf(u?.nome || 'Professor');
        carregar(busca);
      })();
    }, [carregar])
  );

  const sair = async () => {
    await logout();
    navigation.reset({ index: 0, routes: [{ name: 'Home' }] });
  };

  const renderAluno = ({ item }: { item: AlunoResumo }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.8}
      onPress={() => navigation.navigate('FichaAluno', { id: item.id, nome: item.nome })}
    >
      <View style={styles.avatarMini}>
        <Text style={styles.avatarMiniText}>{item.nome[0]?.toUpperCase() || '?'}</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.cardNome} numberOfLines={1}>{item.nome}</Text>
        <Text style={styles.cardEmail} numberOfLines={1}>{item.email}</Text>
      </View>
      <View style={styles.cardRight}>
        <Text style={styles.cardClasse}>{item.classe}</Text>
        <Text style={styles.cardConcluidas}>{item.concluidas} concluída(s)</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />

      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.ola}>Olá, {nomeProf}</Text>
          <Text style={styles.sub}>Acompanhe e avance seus alunos</Text>
        </View>
        <TouchableOpacity onPress={sair} style={styles.sairBtn}>
          <Text style={styles.sairText}>Sair</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.buscaWrap}>
        <TextInput
          style={styles.busca}
          placeholder="Buscar por nome ou email"
          placeholderTextColor={colors.placeholder}
          value={busca}
          onChangeText={setBusca}
          onSubmitEditing={() => carregar(busca)}
          returnKeyType="search"
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.buscaBtn} onPress={() => carregar(busca)}>
          <Text style={styles.buscaBtnText}>Buscar</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator color={colors.accent} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={alunos}
          keyExtractor={(a) => String(a.id)}
          renderItem={renderAluno}
          contentContainerStyle={{ padding: spacing.lg, paddingTop: 0 }}
          ListEmptyComponent={<Text style={styles.vazio}>Nenhum aluno encontrado.</Text>}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xl, paddingBottom: spacing.md },
  ola: { fontSize: 22, fontWeight: 'bold', color: colors.accent },
  sub: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  sairBtn: { backgroundColor: colors.cardSunk, paddingVertical: 8, paddingHorizontal: 14, borderRadius: radii.sm },
  sairText: { color: colors.text, fontWeight: '600' },
  buscaWrap: { flexDirection: 'row', paddingHorizontal: spacing.lg, marginBottom: spacing.md },
  busca: {
    flex: 1, backgroundColor: colors.card, color: colors.text, borderRadius: radii.md,
    paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1, borderColor: colors.border,
  },
  buscaBtn: { backgroundColor: colors.accent, borderRadius: radii.md, paddingHorizontal: 16, justifyContent: 'center', marginLeft: 8 },
  buscaBtnText: { color: colors.onAccent, fontWeight: 'bold' },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card,
    borderRadius: radii.md, padding: spacing.md, marginBottom: spacing.sm,
    borderLeftWidth: 4, borderLeftColor: colors.accent,
  },
  avatarMini: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: colors.accent,
    alignItems: 'center', justifyContent: 'center', marginRight: 12,
  },
  avatarMiniText: { color: colors.onAccent, fontWeight: 'bold', fontSize: 18 },
  cardNome: { color: colors.text, fontWeight: '600', fontSize: 15 },
  cardEmail: { color: colors.textMuted, fontSize: 12, marginTop: 1 },
  cardRight: { alignItems: 'flex-end' },
  cardClasse: { color: colors.accent, fontWeight: 'bold', fontSize: 13 },
  cardConcluidas: { color: colors.textMuted, fontSize: 11, marginTop: 2 },
  vazio: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
});
