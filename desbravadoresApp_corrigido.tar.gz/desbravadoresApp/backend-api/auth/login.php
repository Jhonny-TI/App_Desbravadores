<?php
// POST /auth/login.php  { email, senha }
// -> { token, usuario: {...} }
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$in = corpo();
$email = trim($in['email'] ?? '');
$senha = $in['senha'] ?? '';

if ($email === '' || $senha === '') {
    erro('Informe e-mail e senha.');
}

// --- Proteção contra força bruta ---
// Bloqueia após 5 tentativas falhas do mesmo email+IP em 15 minutos.
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$ident = mb_strtolower($email) . '|' . $ip;

$chk = db()->prepare(
    'SELECT COUNT(*) AS n FROM login_attempts
     WHERE identificador = ? AND criado_em > (NOW() - INTERVAL 15 MINUTE)'
);
$chk->execute([$ident]);
$tentativas = (int) ($chk->fetch()['n'] ?? 0);
if ($tentativas >= 5) {
    erro('Muitas tentativas. Tente novamente em alguns minutos.', 429);
}

$stmt = db()->prepare('SELECT * FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

// Mensagem genérica de propósito (não revela se o email existe)
if (!$user || !password_verify($senha, $user['senha_hash'])) {
    // Registra a tentativa falha
    db()->prepare('INSERT INTO login_attempts (identificador) VALUES (?)')->execute([$ident]);
    erro('E-mail ou senha incorretos.', 401);
}

// Login OK: limpa as tentativas desse identificador
db()->prepare('DELETE FROM login_attempts WHERE identificador = ?')->execute([$ident]);

$token = criar_sessao((int) $user['id']);

responder([
    'token'   => $token,
    'usuario' => usuario_publico($user),
]);
