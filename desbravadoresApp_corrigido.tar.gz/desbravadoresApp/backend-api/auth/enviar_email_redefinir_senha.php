<?php
// POST /auth/enviar_email_redefinir_senha.php  { email }
// Gera token de reset (validade 1h). Em DEV, loga o link no error_log.
// Em produção, envie por email (configure SMTP / use PHPMailer).
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$in = corpo();
$email = trim($in['email'] ?? '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    erro('E-mail inválido.');
}

$stmt = db()->prepare('SELECT id FROM usuarios WHERE email = ? AND ativo = 1 LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

// Resposta SEMPRE de sucesso (não revela se o email existe).
if ($user) {
    $token = gerar_token();
    $ins = db()->prepare(
        'INSERT INTO reset_senha (usuario_id, token, expira_em)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))'
    );
    $ins->execute([$user['id'], $token]);

    // DEV: o link aparece no log do PHP (xampp/apache/logs/error.log).
    // Copie de lá durante os testes.
    error_log("RESET DE SENHA -> token=$token  (use em RedefinirSenha)");
}

responder(['message' => 'Se o e-mail existir, enviamos as instruções de redefinição.']);
