<?php
// POST /auth/logout.php  (header Authorization)
// Invalida o token atual.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$auth = '';
if (function_exists('getallheaders')) {
    $h = getallheaders();
    $auth = $h['Authorization'] ?? $h['authorization'] ?? '';
}
if ($auth === '') {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
}
if (preg_match('/Bearer\s+([a-f0-9]{64})/i', $auth, $m)) {
    $stmt = db()->prepare('DELETE FROM tokens WHERE token = ?');
    $stmt->execute([$m[1]]);
}
responder(['message' => 'Sessão encerrada.']);
