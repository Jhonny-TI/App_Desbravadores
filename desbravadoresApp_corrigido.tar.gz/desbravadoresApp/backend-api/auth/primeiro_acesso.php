<?php
// POST /auth/primeiro_acesso.php  { novaSenha, aceitouTermos }  (header Authorization)
// Troca a senha provisória e registra aceite dos termos.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();

$in = corpo();
$nova = $in['novaSenha'] ?? '';
$aceitou = !empty($in['aceitouTermos']);

if (mb_strlen($nova) < 8) {
    erro('A nova senha deve ter no mínimo 8 caracteres.');
}
if (!$aceitou) {
    erro('É necessário aceitar os Termos de Uso.');
}

$hash = password_hash($nova, PASSWORD_DEFAULT);
db()->prepare(
    'UPDATE usuarios
     SET senha_hash = ?, senha_provisoria = 0, termos_aceitos_em = NOW()
     WHERE id = ?'
)->execute([$hash, $user['id']]);

responder(['message' => 'Primeiro acesso concluído.']);
