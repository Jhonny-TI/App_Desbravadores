<?php
// POST /auth/cadastrar.php  { nome, email, senha, termosAceitos }
// -> { token, usuario: {...} }
// Só cria ALUNO (professor/ADM são criados pelo painel ADM).
// Se o email já existe DESATIVADO, reativa em vez de criar novo.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$in = corpo();
$nome  = trim($in['nome'] ?? '');
$email = trim($in['email'] ?? '');
$senha = $in['senha'] ?? '';
// Aceita tanto 'consentimento' quanto o antigo 'termosAceitos' por compatibilidade
$consentiu = !empty($in['consentimento']) || !empty($in['termosAceitos']);
$nascimento = trim($in['dataNascimento'] ?? ''); // formato esperado: YYYY-MM-DD

// --- Validações (espelham o que o app valida no front) ---
if (mb_strlen($nome) < 3) {
    erro('O nome deve ter no mínimo 3 caracteres.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    erro('E-mail inválido.');
}
if (mb_strlen($senha) < 8) {
    erro('A senha deve ter no mínimo 8 caracteres.');
}
if (!$consentiu) {
    erro('É necessário dar o consentimento para criar a conta.');
}

// Valida a data de nascimento (se informada): formato e intervalo plausível
$nascSql = null;
if ($nascimento !== '') {
    $d = DateTime::createFromFormat('Y-m-d', $nascimento);
    if (!$d || $d->format('Y-m-d') !== $nascimento) {
        erro('Data de nascimento inválida.');
    }
    $ano = (int) $d->format('Y');
    if ($ano < 1900 || $d > new DateTime()) {
        erro('Data de nascimento inválida.');
    }
    $nascSql = $nascimento;
}

$hash = password_hash($senha, PASSWORD_DEFAULT);

// Verifica se já existe conta com esse email (ativa ou não)
$stmt = db()->prepare('SELECT * FROM usuarios WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$existente = $stmt->fetch();

if ($existente) {
    if ((int) $existente['ativo'] === 1) {
        erro('Já existe uma conta com este e-mail.', 409);
    }
    // CONTA DESATIVADA -> REATIVA, mantendo todo o histórico (soft delete)
    $upd = db()->prepare(
        'UPDATE usuarios
         SET ativo = 1, desativado_em = NULL, nome = ?, senha_hash = ?,
             data_nascimento = ?, termos_aceitos_em = NOW(), consentimento_em = NOW()
         WHERE id = ?'
    );
    $upd->execute([$nome, $hash, $nascSql, $existente['id']]);

    $stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
    $stmt->execute([$existente['id']]);
    $user = $stmt->fetch();
} else {
    // Conta nova
    $ins = db()->prepare(
        'INSERT INTO usuarios (nome, email, senha_hash, tipo, classe_ativa, data_nascimento, termos_aceitos_em, consentimento_em)
         VALUES (?, ?, ?, "aluno", "Amigo", ?, NOW(), NOW())'
    );
    $ins->execute([$nome, $email, $hash, $nascSql]);

    $id = (int) db()->lastInsertId();
    $stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
}

$token = criar_sessao((int) $user['id']);

responder([
    'token'   => $token,
    'usuario' => usuario_publico($user),
    'reativada' => (bool) $existente,
], 201);
