<?php
// POST /auth/atualizar_senha.php  { token, novaSenha }
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$in = corpo();
$token = $in['token'] ?? '';
$nova  = $in['novaSenha'] ?? '';

if (mb_strlen($nova) < 8) {
    erro('A nova senha deve ter no mínimo 8 caracteres.');
}

$stmt = db()->prepare(
    'SELECT * FROM reset_senha
     WHERE token = ? AND usado = 0 AND expira_em > NOW() LIMIT 1'
);
$stmt->execute([$token]);
$reset = $stmt->fetch();
if (!$reset) {
    erro('Link inválido ou expirado. Solicite um novo.', 400);
}

$hash = password_hash($nova, PASSWORD_DEFAULT);
db()->prepare('UPDATE usuarios SET senha_hash = ?, senha_provisoria = 0 WHERE id = ?')
    ->execute([$hash, $reset['usuario_id']]);
db()->prepare('UPDATE reset_senha SET usado = 1 WHERE id = ?')
    ->execute([$reset['id']]);
// Invalida sessões antigas por segurança
db()->prepare('DELETE FROM tokens WHERE usuario_id = ?')
    ->execute([$reset['usuario_id']]);

responder(['message' => 'Senha atualizada com sucesso.']);
