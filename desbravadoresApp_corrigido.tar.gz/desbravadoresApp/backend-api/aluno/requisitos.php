<?php
// GET /aluno/requisitos.php?classe=Amigo  (header Authorization)
// -> { marcados: { "0": {foto}, "3": {foto}, ... } }
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('GET');

$user = usuario_autenticado();
$classe = trim($_GET['classe'] ?? '');
if ($classe === '') erro('Informe a classe.');

$stmt = db()->prepare(
    'SELECT indice, foto_url FROM requisitos_marcados
     WHERE usuario_id = ? AND classe = ?'
);
$stmt->execute([$user['id'], $classe]);

$marcados = [];
foreach ($stmt->fetchAll() as $row) {
    $marcados[(string) $row['indice']] = [
        'foto' => $row['foto_url'],   // null se marcado sem foto
    ];
}

// IMPORTANTE: força objeto JSON (chaves "0","2",...) e não array.
// Sem (object), o PHP serializa chaves sequenciais (0,1,2..) como array []
// e o app espera um objeto {}. JSON_FORCE_OBJECT garante o formato.
responder(['marcados' => (object) $marcados]);
