<?php
// POST /aluno/marcar_requisito.php  { classe, indice, marcado: bool }
// Marca/desmarca um requisito SEM foto. (Foto é o upload_foto.php.)
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();
exigir_tipo($user, ['aluno']);

$in = corpo();
$classe  = trim($in['classe'] ?? '');
$indice  = isset($in['indice']) ? (int) $in['indice'] : -1;
$marcado = !empty($in['marcado']);

if ($classe === '' || $indice < 0) erro('Dados inválidos.');

if ($marcado) {
    // Marca (se já existir, não duplica por causa da UNIQUE KEY)
    $stmt = db()->prepare(
        'INSERT INTO requisitos_marcados (usuario_id, classe, indice)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE marcado_em = marcado_em'
    );
    $stmt->execute([$user['id'], $classe, $indice]);
} else {
    // Desmarca: apaga a linha. Se tinha foto, remove o arquivo (anti-órfã).
    apagar_requisito_com_foto((int) $user['id'], $classe, $indice);
}

responder(['ok' => true]);

// ----- helper compartilhado -----
function apagar_requisito_com_foto(int $uid, string $classe, int $indice): void {
    $sel = db()->prepare(
        'SELECT foto_url FROM requisitos_marcados
         WHERE usuario_id = ? AND classe = ? AND indice = ? LIMIT 1'
    );
    $sel->execute([$uid, $classe, $indice]);
    $row = $sel->fetch();
    if ($row && $row['foto_url']) {
        remover_arquivo_upload($row['foto_url']);
    }
    db()->prepare(
        'DELETE FROM requisitos_marcados WHERE usuario_id = ? AND classe = ? AND indice = ?'
    )->execute([$uid, $classe, $indice]);
}

// Remove fisicamente o arquivo da pasta uploads/ a partir da URL salva
function remover_arquivo_upload(string $url): void {
    $nome = basename(parse_url($url, PHP_URL_PATH) ?: $url);
    $caminho = __DIR__ . '/../uploads/' . $nome;
    if ($nome !== '' && is_file($caminho)) {
        @unlink($caminho);
    }
}
