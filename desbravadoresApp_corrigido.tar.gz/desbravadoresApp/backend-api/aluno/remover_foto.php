<?php
// POST /aluno/remover_foto.php  { classe, indice }
// Remove SÓ a foto (mantém o requisito marcado). É a lixeira ao lado da foto.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();
exigir_tipo($user, ['aluno']);

$in = corpo();
$classe = trim($in['classe'] ?? '');
$indice = isset($in['indice']) ? (int) $in['indice'] : -1;
if ($classe === '' || $indice < 0) erro('Dados inválidos.');

$sel = db()->prepare(
    'SELECT foto_url FROM requisitos_marcados
     WHERE usuario_id = ? AND classe = ? AND indice = ? LIMIT 1'
);
$sel->execute([$user['id'], $classe, $indice]);
$row = $sel->fetch();

if ($row && $row['foto_url']) {
    // Apaga arquivo físico (anti-órfã)
    $nome = basename(parse_url($row['foto_url'], PHP_URL_PATH) ?: '');
    $caminho = __DIR__ . '/../uploads/' . $nome;
    if ($nome !== '' && is_file($caminho)) @unlink($caminho);

    // Mantém o requisito marcado, só zera a foto
    db()->prepare(
        'UPDATE requisitos_marcados SET foto_url = NULL
         WHERE usuario_id = ? AND classe = ? AND indice = ?'
    )->execute([$user['id'], $classe, $indice]);
}

responder(['ok' => true]);
