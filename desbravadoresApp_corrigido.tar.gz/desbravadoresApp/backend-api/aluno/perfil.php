<?php
// GET  /aluno/perfil.php           -> dados do perfil
// PUT  /aluno/perfil.php  { nome, classe, fotoUrl }  -> atualiza
require_once __DIR__ . '/../_core/bootstrap.php';

$user = usuario_autenticado();
$metodo = $_SERVER['REQUEST_METHOD'];

if ($metodo === 'GET') {
    // Classes concluídas (histórico)
    $cc = db()->prepare('SELECT classe, concluido_por_nome, concluido_em, ajuste_admin
                         FROM classes_concluidas WHERE usuario_id = ? ORDER BY concluido_em');
    $cc->execute([$user['id']]);
    $concluidas = $cc->fetchAll();

    // Total de requisitos cumpridos (em todas as classes)
    $rc = db()->prepare('SELECT COUNT(*) AS n FROM requisitos_marcados WHERE usuario_id = ?');
    $rc->execute([$user['id']]);
    $totalRequisitos = (int) ($rc->fetch()['n'] ?? 0);

    responder([
        'usuario'    => usuario_publico($user),
        'concluidas' => $concluidas,
        'totalConcluidas'  => count($concluidas),
        'totalRequisitos'  => $totalRequisitos,
    ]);
}

if ($metodo === 'PUT') {
    $in = corpo();
    $campos = [];
    $vals = [];

    // Detecta se há mudança sensível (email ou senha) — exige a senha atual.
    $mudaEmail = isset($in['email']) && trim($in['email']) !== $user['email'];
    $mudaSenha = isset($in['senha']) && $in['senha'] !== '';
    if ($mudaEmail || $mudaSenha) {
        $senhaAtual = $in['senhaAtual'] ?? '';
        if ($senhaAtual === '' || !password_verify($senhaAtual, $user['senha_hash'])) {
            erro('Senha atual incorreta.', 401);
        }
    }

    if (isset($in['nome']) && mb_strlen(trim($in['nome'])) >= 3) {
        $campos[] = 'nome = ?'; $vals[] = trim($in['nome']);
    }

    // Troca de e-mail: valida formato e garante que não está em uso por outra conta
    if ($mudaEmail) {
        $novoEmail = trim($in['email']);
        if (!filter_var($novoEmail, FILTER_VALIDATE_EMAIL)) {
            erro('E-mail inválido.');
        }
        $chk = db()->prepare('SELECT id FROM usuarios WHERE email = ? AND id <> ? LIMIT 1');
        $chk->execute([$novoEmail, $user['id']]);
        if ($chk->fetch()) {
            erro('Este e-mail já está em uso por outra conta.', 409);
        }
        $campos[] = 'email = ?'; $vals[] = $novoEmail;
    }

    // Troca de senha: mínimo 8 caracteres, guardada com hash
    if ($mudaSenha) {
        if (mb_strlen($in['senha']) < 8) {
            erro('A nova senha deve ter no mínimo 8 caracteres.');
        }
        $campos[] = 'senha_hash = ?'; $vals[] = password_hash($in['senha'], PASSWORD_DEFAULT);
    }

    // SEGURANÇA: o aluno NÃO pode mudar a própria classe por aqui.
    if (isset($in['fotoUrl'])) {
        $campos[] = 'foto_url = ?'; $vals[] = $in['fotoUrl'];
    }
    if (!$campos) erro('Nada para atualizar.');

    $vals[] = $user['id'];
    db()->prepare('UPDATE usuarios SET ' . implode(', ', $campos) . ' WHERE id = ?')
        ->execute($vals);

    $stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ?');
    $stmt->execute([$user['id']]);
    responder(['usuario' => usuario_publico($stmt->fetch())]);
}

erro('Método não permitido.', 405);
