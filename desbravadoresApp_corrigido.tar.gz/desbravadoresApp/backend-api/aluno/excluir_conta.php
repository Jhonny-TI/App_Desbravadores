<?php
// DELETE /aluno/excluir_conta.php  { nomeConfirmacao, senha }
// HARD DELETE definitivo (direito do titular - LGPD).
// Diferente do "desativar" do ADM: aqui apaga DE VERDADE, sem volta.
// Exige confirmação: digitar o próprio nome + a senha.
require_once __DIR__ . '/../_core/bootstrap.php';

// Aceita DELETE ou POST (alguns proxies bloqueiam DELETE com corpo)
if (!in_array($_SERVER['REQUEST_METHOD'], ['DELETE', 'POST'], true)) {
    erro('Método não permitido.', 405);
}

$user = usuario_autenticado();

$in = corpo();
$nomeConf = trim($in['nomeConfirmacao'] ?? '');
$senha    = $in['senha'] ?? '';

// --- Dupla confirmação ---
if ($nomeConf !== $user['nome']) {
    erro('O nome digitado não confere com o nome da conta.');
}
if (!password_verify($senha, $user['senha_hash'])) {
    erro('Senha incorreta.', 401);
}

$pdo = db();

// 1) Coleta todas as fotos do usuário ANTES de apagar (pra limpar o disco)
$fotos = $pdo->prepare('SELECT foto_url FROM requisitos_marcados WHERE usuario_id = ? AND foto_url IS NOT NULL');
$fotos->execute([$user['id']]);
$arquivos = array_column($fotos->fetchAll(), 'foto_url');

// foto de perfil também
if (!empty($user['foto_url'])) {
    $arquivos[] = $user['foto_url'];
}

// 2) Apaga o usuário. As tabelas filhas têm ON DELETE CASCADE,
//    então requisitos, classes concluídas e tokens vão junto.
$pdo->prepare('DELETE FROM usuarios WHERE id = ?')->execute([$user['id']]);

// 3) Remove os arquivos físicos (anti-órfã)
foreach ($arquivos as $url) {
    $nome = basename(parse_url($url, PHP_URL_PATH) ?: '');
    $caminho = __DIR__ . '/../uploads/' . $nome;
    if ($nome !== '' && is_file($caminho)) @unlink($caminho);
}

responder(['message' => 'Conta excluída permanentemente.']);
