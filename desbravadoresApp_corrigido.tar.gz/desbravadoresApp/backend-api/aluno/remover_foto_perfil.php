<?php
// POST /aluno/remover_foto_perfil.php   (header Authorization)
// Remove a foto de perfil: apaga o arquivo do disco (anti-órfã) e zera foto_url.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();
$atual = $user['foto_url'] ?? null;

if ($atual) {
    $nome = basename(parse_url($atual, PHP_URL_PATH) ?: '');
    $caminho = __DIR__ . '/../uploads/' . $nome;
    if ($nome !== '' && is_file($caminho)) @unlink($caminho);
}

db()->prepare('UPDATE usuarios SET foto_url = NULL WHERE id = ?')->execute([$user['id']]);

responder(['ok' => true]);
