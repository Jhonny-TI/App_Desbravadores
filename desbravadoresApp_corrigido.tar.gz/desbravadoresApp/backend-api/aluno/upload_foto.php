<?php
// POST /aluno/upload_foto.php   (multipart/form-data)
//   campos: classe (text), indice (text), foto (file)
// -> { fotoUrl }
// Salva a imagem em uploads/, vincula ao requisito e marca como concluído.
// ANTI-ÓRFÃ: se o requisito já tinha uma foto, apaga a antiga antes.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();
exigir_tipo($user, ['aluno']);

$classe = trim($_POST['classe'] ?? '');
$indice = isset($_POST['indice']) ? (int) $_POST['indice'] : -1;

if ($classe === '' || $indice < 0) {
    erro('Dados inválidos.');
}
if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
    erro('Falha no envio da imagem.');
}

$file = $_FILES['foto'];

// --- Validação de tipo (só imagens) e tamanho (máx 8 MB) ---
$permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!isset($permitidos[$mime])) {
    erro('Formato inválido. Envie JPG, PNG ou WEBP.');
}
if ($file['size'] > 8 * 1024 * 1024) {
    erro('Imagem muito grande (máximo 8 MB).');
}

// --- Nome único e seguro pro arquivo ---
$ext = $permitidos[$mime];
$nomeArquivo = sprintf('u%d_%s_%d_%s.%s',
    $user['id'], preg_replace('/[^a-zA-Z]/', '', $classe), $indice, bin2hex(random_bytes(6)), $ext);
$destino = __DIR__ . '/../uploads/' . $nomeArquivo;

if (!move_uploaded_file($file['tmp_name'], $destino)) {
    erro('Não foi possível salvar a imagem.', 500);
}

$novaUrl = url_upload($nomeArquivo);

// --- Transação: apaga foto antiga (anti-órfã) e grava a nova ---
$pdo = db();
$pdo->beginTransaction();
try {
    // Foto antiga do mesmo requisito?
    $sel = $pdo->prepare(
        'SELECT foto_url FROM requisitos_marcados
         WHERE usuario_id = ? AND classe = ? AND indice = ? LIMIT 1'
    );
    $sel->execute([$user['id'], $classe, $indice]);
    $antiga = $sel->fetch();

    // Insere ou atualiza o requisito com a nova foto
    $up = $pdo->prepare(
        'INSERT INTO requisitos_marcados (usuario_id, classe, indice, foto_url)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE foto_url = VALUES(foto_url), marcado_em = NOW()'
    );
    $up->execute([$user['id'], $classe, $indice, $novaUrl]);

    $pdo->commit();

    // Só depois do commit apagamos o arquivo antigo do disco
    if ($antiga && $antiga['foto_url'] && $antiga['foto_url'] !== $novaUrl) {
        $nome = basename(parse_url($antiga['foto_url'], PHP_URL_PATH) ?: '');
        $caminhoAntigo = __DIR__ . '/../uploads/' . $nome;
        if ($nome !== '' && is_file($caminhoAntigo)) @unlink($caminhoAntigo);
    }
} catch (Throwable $e) {
    $pdo->rollBack();
    @unlink($destino); // não deixa órfã se o banco falhou
    error_log('upload_foto: ' . $e->getMessage());
    erro('Erro ao registrar a imagem.', 500);
}

responder(['fotoUrl' => $novaUrl]);
