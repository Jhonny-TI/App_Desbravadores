<?php
// POST /aluno/upload_foto_perfil.php  (multipart/form-data, campo: foto)
// -> { fotoUrl }
// Salva a foto de perfil em uploads/, grava a URL em usuarios.foto_url e
// apaga a foto antiga do disco (anti-órfã). Funciona p/ qualquer usuário logado.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$user = usuario_autenticado();

if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
    erro('Falha no envio da imagem.');
}
$file = $_FILES['foto'];

// Validação de tipo (MIME real) e tamanho (máx 8 MB)
$permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);
if (!isset($permitidos[$mime])) {
    erro('Formato inválido. Envie JPG, PNG ou WEBP.');
}
if ($file['size'] > 8 * 1024 * 1024) {
    erro('Imagem muito grande (máximo 8 MB).');
}

// Nome único e seguro
$ext = $permitidos[$mime];
$nomeArquivo = sprintf('perfil_u%d_%s.%s', $user['id'], bin2hex(random_bytes(6)), $ext);
$destino = __DIR__ . '/../uploads/' . $nomeArquivo;

if (!move_uploaded_file($file['tmp_name'], $destino)) {
    erro('Não foi possível salvar a imagem.', 500);
}

$novaUrl = url_upload($nomeArquivo);
$antiga = $user['foto_url'] ?? null;

// Atualiza a URL no banco
try {
    db()->prepare('UPDATE usuarios SET foto_url = ? WHERE id = ?')
        ->execute([$novaUrl, $user['id']]);
} catch (Throwable $e) {
    @unlink($destino); // não deixa órfã se o banco falhar
    error_log('upload_foto_perfil: ' . $e->getMessage());
    erro('Erro ao registrar a imagem.', 500);
}

// Apaga o arquivo antigo do disco (anti-órfã)
if ($antiga && $antiga !== $novaUrl) {
    $nome = basename(parse_url($antiga, PHP_URL_PATH) ?: '');
    $caminhoAntigo = __DIR__ . '/../uploads/' . $nome;
    if ($nome !== '' && is_file($caminhoAntigo)) @unlink($caminhoAntigo);
}

responder(['fotoUrl' => $novaUrl]);
