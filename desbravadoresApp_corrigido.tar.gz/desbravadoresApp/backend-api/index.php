<?php
require_once __DIR__ . '/_core/bootstrap.php';
responder([
    'api'   => 'Desbravadores API',
    'status'=> 'online',
    'versao'=> '1.0',
]);
