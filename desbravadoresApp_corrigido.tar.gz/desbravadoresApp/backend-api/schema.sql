-- =====================================================================
-- BANCO DE DADOS: desbravadores_db
-- =====================================================================
-- Como usar (XAMPP):
--   1. Abra o phpMyAdmin (http://localhost/phpmyadmin)
--   2. Vá em "Importar" e selecione este arquivo
--   OU rode no terminal:
--   mysql -u root -p < schema.sql
--
-- JÁ TEM O BANCO CRIADO? Rode só esta linha pra adicionar o consentimento:
--   ALTER TABLE usuarios ADD COLUMN consentimento_em DATETIME DEFAULT NULL;
-- =====================================================================

CREATE DATABASE IF NOT EXISTS desbravadores_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE desbravadores_db;

-- ---------------------------------------------------------------------
-- USUÁRIOS (alunos, professores e ADMs na mesma tabela, separados por `tipo`)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  nome            VARCHAR(144) NOT NULL,
  email           VARCHAR(244) NOT NULL,
  senha_hash      VARCHAR(255) NOT NULL,
  tipo            ENUM('aluno','professor') NOT NULL DEFAULT 'aluno',
  classe_ativa    VARCHAR(40) DEFAULT 'Amigo',   -- só relevante p/ aluno
  data_nascimento DATE DEFAULT NULL,             -- usado p/ calcular idade
  foto_url        VARCHAR(255) DEFAULT NULL,

  -- Controle de primeiro acesso (professor/ADM criados pelo painel)
  senha_provisoria TINYINT(1) NOT NULL DEFAULT 0, -- 1 = precisa trocar no 1º login
  termos_aceitos_em DATETIME DEFAULT NULL,        -- NULL = ainda não aceitou os termos

  -- CONSENTIMENTO LGPD: registra quando a pessoa consentiu com a coleta de dados.
  -- NULL = nunca consentiu. Guardar a data é o que a LGPD exige (consentimento
  -- informado e auditável).
  consentimento_em DATETIME DEFAULT NULL,

  -- SOFT DELETE: conta desativada não some do banco. Some das listas
  -- e não consegue logar. Se recriada com o mesmo email, é reativada.
  ativo           TINYINT(1) NOT NULL DEFAULT 1,
  desativado_em   DATETIME DEFAULT NULL,

  criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  -- email é único só entre contas... na prática deixamos único geral e
  -- a lógica de reativação (no cadastrar.php) lida com email já existente.
  UNIQUE KEY uq_email (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TOKENS DE SESSÃO (autenticação por token simples)
-- ---------------------------------------------------------------------
-- A cada login geramos um token aleatório. O app guarda e manda no
-- header Authorization de cada request. Logout apaga o token.
CREATE TABLE IF NOT EXISTS tokens (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  token       CHAR(64) NOT NULL,
  expira_em   DATETIME NOT NULL,
  criado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_token (token),
  KEY idx_usuario (usuario_id),
  CONSTRAINT fk_token_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TOKENS DE RECUPERAÇÃO DE SENHA
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reset_senha (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  token       CHAR(64) NOT NULL,
  expira_em   DATETIME NOT NULL,           -- validade curta (1h)
  usado       TINYINT(1) NOT NULL DEFAULT 0,
  criado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reset_token (token),
  CONSTRAINT fk_reset_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- REQUISITOS MARCADOS pelo aluno
-- ---------------------------------------------------------------------
-- Cada linha = um requisito (identificado por classe + índice) marcado
-- por um aluno, com a foto de evidência opcional.
CREATE TABLE IF NOT EXISTS requisitos_marcados (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id   INT NOT NULL,
  classe       VARCHAR(40) NOT NULL,       -- ex: "Amigo"
  indice       INT NOT NULL,               -- posição do requisito na lista
  foto_url     VARCHAR(255) DEFAULT NULL,  -- evidência (NULL = marcado sem foto)
  marcado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_req (usuario_id, classe, indice),
  KEY idx_usuario_classe (usuario_id, classe),
  CONSTRAINT fk_req_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CLASSES CONCLUÍDAS (histórico do aluno)
-- ---------------------------------------------------------------------
-- Preenchida pelo professor/ADM quando marca uma classe como concluída.
-- As classes ACUMULAM (aluno pode ter várias concluídas).
-- `concluido_por_nome` guarda o NOME EM TEXTO de quem concluiu, pra
-- sobreviver mesmo se a conta do professor for desativada/excluída.
CREATE TABLE IF NOT EXISTS classes_concluidas (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id          INT NOT NULL,
  classe              VARCHAR(40) NOT NULL,
  concluido_por_nome  VARCHAR(144) NOT NULL,
  ajuste_admin        TINYINT(1) NOT NULL DEFAULT 0, -- 1 = intervenção de ADM
  concluido_em        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_classe_concluida (usuario_id, classe),
  KEY idx_usuario (usuario_id),
  CONSTRAINT fk_concl_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TENTATIVAS DE LOGIN (proteção contra força bruta)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  identificador VARCHAR(255) NOT NULL,  -- email + ip
  criado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ident_data (identificador, criado_em)
) ENGINE=InnoDB;

-- =====================================================================
-- SEMENTE: o professor do clube
-- =====================================================================
-- O aluno se cadastra sozinho pelo app. O PROFESSOR é criado aqui, na
-- instalação (não há auto-cadastro de professor). Troque a senha no
-- primeiro login. Gere um hash novo com:
--   php -r "echo password_hash('suaSenha', PASSWORD_DEFAULT);"
INSERT INTO usuarios (nome, email, senha_hash, tipo, senha_provisoria, termos_aceitos_em)
VALUES (
  'Professor',
  'professor@desbravadores.local',
  '$2y$10$e0NRzD2c5p9xqKZ8wYmuP.Hh0pXqXqXqXqXqXqXqXqXqXqXqXqXq', -- placeholder, troque!
  'professor',
  1,
  NULL
)
ON DUPLICATE KEY UPDATE email = email;  -- não duplica se rodar 2x
