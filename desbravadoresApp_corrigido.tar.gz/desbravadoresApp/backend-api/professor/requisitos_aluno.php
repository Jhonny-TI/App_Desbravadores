<?php
// GET /professor/requisitos_aluno.php?id=123&classe=Amigo
// Devolve os requisitos que o aluno marcou naquela classe, com a foto.
// É o que permite o professor verificar as evidências uma a uma.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('GET');

$prof = usuario_autenticado();
exigir_tipo($prof, ['professor']);

$id = (int) ($_GET['id'] ?? 0);
$classe = trim($_GET['classe'] ?? '');
if ($id <= 0 || $classe === '') erro('Parâmetros inválidos.');

// Confirma que é um aluno mesmo
$a = db()->prepare('SELECT id FROM usuarios WHERE id = ? AND tipo = "aluno" LIMIT 1');
$a->execute([$id]);
if (!$a->fetch()) erro('Aluno não encontrado.', 404);

$stmt = db()->prepare(
    'SELECT indice, foto_url, marcado_em FROM requisitos_marcados
     WHERE usuario_id = ? AND classe = ?'
);
$stmt->execute([$id, $classe]);

$marcados = [];
foreach ($stmt->fetchAll() as $row) {
    $marcados[(string) $row['indice']] = [
        'foto' => $row['foto_url'],          // null = marcado sem foto
        'marcadoEm' => $row['marcado_em'],
    ];
}

responder(['classe' => $classe, 'marcados' => (object) $marcados]);
