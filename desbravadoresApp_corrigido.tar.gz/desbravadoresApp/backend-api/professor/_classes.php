<?php
// Ordem oficial das classes (compartilhada pelos endpoints do professor).
// Avançar = concluir a classe atual e ir para a próxima desta lista.
return ['Amigo', 'Companheiro', 'Pesquisador', 'Pioneiro', 'Excursionista', 'Guia'];
