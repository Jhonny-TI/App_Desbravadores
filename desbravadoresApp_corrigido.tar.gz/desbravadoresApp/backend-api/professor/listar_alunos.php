<?php
// GET /professor/listar_alunos.php?busca=texto&incluirInativos=0
// Lista alunos (ativos por padrão), com busca por nome ou email.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('GET');

$prof = usuario_autenticado();
exigir_tipo($prof, ['professor']);

$busca = trim($_GET['busca'] ?? '');
$incluirInativos = ($_GET['incluirInativos'] ?? '0') === '1';

$sql = 'SELECT u.id, u.nome, u.email, u.classe_ativa, u.ativo,
               (SELECT COUNT(*) FROM classes_concluidas c WHERE c.usuario_id = u.id) AS concluidas
        FROM usuarios u
        WHERE u.tipo = "aluno"';
$params = [];

if (!$incluirInativos) {
    $sql .= ' AND u.ativo = 1';
}
if ($busca !== '') {
    $sql .= ' AND (u.nome LIKE ? OR u.email LIKE ?)';
    $params[] = "%$busca%";
    $params[] = "%$busca%";
}
$sql .= ' ORDER BY u.nome';

$stmt = db()->prepare($sql);
$stmt->execute($params);

$alunos = array_map(function ($a) {
    return [
        'id'       => (int) $a['id'],
        'nome'     => $a['nome'],
        'email'    => $a['email'],
        'classe'   => $a['classe_ativa'],
        'ativo'    => (bool) $a['ativo'],
        'concluidas' => (int) $a['concluidas'],
    ];
}, $stmt->fetchAll());

responder(['alunos' => $alunos]);
