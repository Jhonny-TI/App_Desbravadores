<?php
// POST /professor/avancar_classe.php  { alunoId }
// Conclui a classe ATUAL do aluno (registra no histórico) e move a
// classe ativa para a PRÓXIMA da ordem. As classes acumulam.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$prof = usuario_autenticado();
exigir_tipo($prof, ['professor']);

$in = corpo();
$alunoId = (int) ($in['alunoId'] ?? 0);
if ($alunoId <= 0) erro('Aluno inválido.');

$stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ? AND tipo = "aluno" AND ativo = 1 LIMIT 1');
$stmt->execute([$alunoId]);
$aluno = $stmt->fetch();
if (!$aluno) erro('Aluno não encontrado.', 404);

$ordem = require __DIR__ . '/_classes.php';
$atual = $aluno['classe_ativa'];
$pos = array_search($atual, $ordem, true);

if ($pos === false) erro('Classe atual desconhecida.');
if ($pos >= count($ordem) - 1) {
    erro('O aluno já está na última classe (' . $atual . ').');
}
$proxima = $ordem[$pos + 1];

$pdo = db();
$pdo->beginTransaction();
try {
    // Registra a classe atual como concluída (não duplica se já estiver)
    $pdo->prepare(
        'INSERT INTO classes_concluidas (usuario_id, classe, concluido_por_nome)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE concluido_em = NOW(), concluido_por_nome = VALUES(concluido_por_nome)'
    )->execute([$alunoId, $atual, $prof['nome']]);

    // Move a classe ativa para a próxima
    $pdo->prepare('UPDATE usuarios SET classe_ativa = ? WHERE id = ?')
        ->execute([$proxima, $alunoId]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('avancar_classe: ' . $e->getMessage());
    erro('Erro ao avançar a classe.', 500);
}

responder([
    'message' => "Classe $atual concluída. Classe ativa agora: $proxima.",
    'classeConcluida' => $atual,
    'classeAtiva' => $proxima,
]);
