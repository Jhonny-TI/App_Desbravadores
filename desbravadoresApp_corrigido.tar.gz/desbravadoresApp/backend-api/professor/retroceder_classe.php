<?php
// POST /professor/retroceder_classe.php  { alunoId }
// Desfaz: volta a classe ativa para a anterior e remove a conclusão dela.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('POST');

$prof = usuario_autenticado();
exigir_tipo($prof, ['professor']);

$in = corpo();
$alunoId = (int) ($in['alunoId'] ?? 0);
if ($alunoId <= 0) erro('Aluno inválido.');

$stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ? AND tipo = "aluno" AND ativo = 1 LIMIT 1');
$stmt->execute([$alunoId]);
$aluno = $stmt->fetch();
if (!$aluno) erro('Aluno não encontrado.', 404);

$ordem = require __DIR__ . '/_classes.php';
$atual = $aluno['classe_ativa'];
$pos = array_search($atual, $ordem, true);

if ($pos === false) erro('Classe atual desconhecida.');
if ($pos <= 0) {
    erro('O aluno já está na primeira classe (' . $atual . ').');
}
$anterior = $ordem[$pos - 1];

$pdo = db();
$pdo->beginTransaction();
try {
    // Volta a classe ativa para a anterior
    $pdo->prepare('UPDATE usuarios SET classe_ativa = ? WHERE id = ?')
        ->execute([$anterior, $alunoId]);
    // Remove o registro de conclusão da classe anterior (foi desfeita)
    $pdo->prepare('DELETE FROM classes_concluidas WHERE usuario_id = ? AND classe = ?')
        ->execute([$alunoId, $anterior]);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('retroceder_classe: ' . $e->getMessage());
    erro('Erro ao retroceder a classe.', 500);
}

responder([
    'message' => "Classe ativa voltou para $anterior.",
    'classeAtiva' => $anterior,
]);
