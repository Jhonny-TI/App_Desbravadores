<?php
// GET /professor/ficha_aluno.php?id=123
// Ficha completa de um aluno: dados, classe atual, classes concluídas (histórico),
// e a próxima classe que o professor pode liberar.
require_once __DIR__ . '/../_core/bootstrap.php';
exigir_metodo('GET');

$prof = usuario_autenticado();
exigir_tipo($prof, ['professor']);

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) erro('Aluno inválido.');

$stmt = db()->prepare('SELECT * FROM usuarios WHERE id = ? AND tipo = "aluno" LIMIT 1');
$stmt->execute([$id]);
$aluno = $stmt->fetch();
if (!$aluno) erro('Aluno não encontrado.', 404);

// Histórico de classes concluídas
$cc = db()->prepare('SELECT classe, concluido_por_nome, concluido_em
                     FROM classes_concluidas WHERE usuario_id = ? ORDER BY concluido_em');
$cc->execute([$id]);
$concluidas = $cc->fetchAll();

// Total de requisitos cumpridos
$rc = db()->prepare('SELECT COUNT(*) AS n FROM requisitos_marcados WHERE usuario_id = ?');
$rc->execute([$id]);
$totalReq = (int) ($rc->fetch()['n'] ?? 0);

// Próxima classe disponível a partir da classe ativa
$ordem = require __DIR__ . '/_classes.php';
$pos = array_search($aluno['classe_ativa'], $ordem, true);
$proxima = ($pos !== false && $pos < count($ordem) - 1) ? $ordem[$pos + 1] : null;

responder([
    'aluno' => usuario_publico($aluno),
    'concluidas' => $concluidas,
    'totalRequisitos' => $totalReq,
    'ordemClasses' => $ordem,
    'proximaClasse' => $proxima,   // null = já está na última (Guia)
]);
