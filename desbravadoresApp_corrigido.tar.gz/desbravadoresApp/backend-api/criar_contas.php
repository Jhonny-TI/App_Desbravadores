<?php
// =====================================================================
// CRIAR CONTAS — script de semente (rode UMA vez)
// =====================================================================
// Cria uma conta de PROFESSOR e uma de ALUNO já prontas para login.
// Como usar:
//   - No navegador:  http://localhost/backend-api/criar_contas.php
//   - Ou no terminal: php criar_contas.php
//
// >>> APAGUE ESTE ARQUIVO depois de usar. <<<
// Deixá-lo no servidor permite que alguém crie contas de professor.
// =====================================================================

// ----- EDITE AQUI as credenciais que quiser -----
$CONTAS = [
    [
        'tipo'  => 'professor',
        'nome'  => 'Professor',
        'email' => 'professor@desbravadores.local',
        'senha' => 'prof12345',          // troque depois do primeiro login
        'data_nascimento' => null,
    ],
    [
        'tipo'  => 'aluno',
        'nome'  => 'Aluno Teste',
        'email' => 'aluno@desbravadores.local',
        'senha' => 'aluno12345',
        'data_nascimento' => '2012-05-10', // YYYY-MM-DD (ou null)
    ],
];
// -------------------------------------------------

// --- Trava de segurança: só localhost ou linha de comando ---
$cli = (php_sapi_name() === 'cli');
$ip  = $_SERVER['REMOTE_ADDR'] ?? '';
$ehLocal = in_array($ip, ['127.0.0.1', '::1'], true);
if (!$cli && !$ehLocal) {
    http_response_code(403);
    exit('Acesso negado. Este script só roda localmente.');
}

// Saída em texto puro (legível no navegador e no terminal)
if (!$cli) header('Content-Type: text/plain; charset=utf-8');

// --- Conexão usando o mesmo config do sistema ---
$cfg = require __DIR__ . '/_core/config.php';
try {
    $dsn = "mysql:host={$cfg['host']};port={$cfg['porta']};dbname={$cfg['banco']};charset={$cfg['charset']}";
    $pdo = new PDO($dsn, $cfg['usuario'], $cfg['senha'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    exit("ERRO: não consegui conectar ao banco. Verifique o config.php.\n" . $e->getMessage() . "\n");
}

echo "=== Criando contas ===\n\n";

foreach ($CONTAS as $c) {
    $hash = password_hash($c['senha'], PASSWORD_DEFAULT);

    // Já existe alguém com esse email?
    $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $stmt->execute([$c['email']]);
    $existente = $stmt->fetch();

    if ($existente) {
        // JÁ EXISTE -> garante as credenciais configuradas (redefine a senha,
        // reativa, atualiza nome/tipo). É isso que faz o login funcionar mesmo
        // quando o schema já tinha semeado a conta com uma senha placeholder.
        $upd = $pdo->prepare(
            'UPDATE usuarios
             SET ativo = 1, desativado_em = NULL, nome = ?, senha_hash = ?, tipo = ?,
                 data_nascimento = ?, senha_provisoria = 0,
                 termos_aceitos_em = NOW(), consentimento_em = NOW()
             WHERE id = ?'
        );
        $upd->execute([$c['nome'], $hash, $c['tipo'], $c['data_nascimento'], $existente['id']]);
        echo "• {$c['email']} — já existia: SENHA REDEFINIDA para a configurada.\n";
    } else {
        // Conta nova
        $ins = $pdo->prepare(
            'INSERT INTO usuarios
               (nome, email, senha_hash, tipo, classe_ativa, data_nascimento, senha_provisoria, termos_aceitos_em, consentimento_em)
             VALUES (?, ?, ?, ?, ?, ?, 0, NOW(), NOW())'
        );
        $classe = 'Amigo'; // relevante p/ aluno; ignorada p/ professor
        $ins->execute([$c['nome'], $c['email'], $hash, $c['tipo'], $classe, $c['data_nascimento']]);
        echo "• {$c['email']} — criada.\n";
    }

    echo "    tipo:  {$c['tipo']}\n";
    echo "    login: {$c['email']}\n";
    echo "    senha: {$c['senha']}\n\n";
}

echo "=== Concluído ===\n\n";
echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
echo "  APAGUE ESTE ARQUIVO (criar_contas.php) AGORA.\n";
echo "  Deixá-lo no servidor é um risco de segurança.\n";
echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
