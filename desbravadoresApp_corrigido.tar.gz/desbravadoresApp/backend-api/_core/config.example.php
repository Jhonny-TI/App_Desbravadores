<?php
// =====================================================================
// MODELO DE CONFIGURAÇÃO
// =====================================================================
// 1. Copie este arquivo para "config.php" (na mesma pasta).
// 2. Preencha com as credenciais reais do seu banco.
// O config.php real é ignorado pelo Git (.gitignore) pra não vazar senha.

return [
    'host'    => '127.0.0.1',
    'porta'   => '3306',
    'banco'   => 'desbravadores_db',
    'usuario' => 'root',
    'senha'   => '',           // XAMPP normalmente vem sem senha no root
    'charset' => 'utf8mb4',
    'uploads_base_url' => '',  // '' = detecta automaticamente
];
