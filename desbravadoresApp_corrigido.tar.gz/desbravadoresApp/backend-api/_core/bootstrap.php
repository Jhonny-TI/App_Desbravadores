<?php
// =====================================================================
// NÚCLEO DO BACKEND — incluído no topo de TODO endpoint
// =====================================================================
// Responsável por: CORS, conexão PDO, leitura do corpo JSON,
// respostas JSON padronizadas e autenticação por token.
//
// Uso no topo de cada arquivo de endpoint:
//   require_once __DIR__ . '/../_core/bootstrap.php';
// =====================================================================

// ---- Erros: em dev mostra, em produção esconde (logue em arquivo) ----
error_reporting(E_ALL);
ini_set('display_errors', '0');           // não vaza erro no JSON
ini_set('log_errors', '1');

// ---- CORS: permite o app (Expo/web) chamar a API ----
// DEV: '*' libera qualquer origem (ok pra desenvolvimento).
// PRODUÇÃO: troque '*' pelo domínio exato do seu app web, ex.:
//   header('Access-Control-Allow-Origin: https://seuapp.com');
// (Apps nativos via Expo Go não são afetados por CORS, só o alvo web.)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Requisição "preflight" do navegador — responde 200 e encerra.
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ---------------------------------------------------------------------
// Conexão com o banco (PDO)
// ---------------------------------------------------------------------
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $cfg = require __DIR__ . '/config.php';
    $dsn = "mysql:host={$cfg['host']};port={$cfg['porta']};dbname={$cfg['banco']};charset={$cfg['charset']}";
    try {
        $pdo = new PDO($dsn, $cfg['usuario'], $cfg['senha'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        error_log('Falha de conexão DB: ' . $e->getMessage());
        responder(['message' => 'Erro de conexão com o banco de dados.'], 500);
    }
    return $pdo;
}

// ---------------------------------------------------------------------
// Resposta JSON padronizada + encerra a execução
// ---------------------------------------------------------------------
function responder($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function erro(string $mensagem, int $status = 400): void {
    responder(['message' => $mensagem], $status);
}

// ---------------------------------------------------------------------
// Lê o corpo JSON do request e devolve como array associativo
// ---------------------------------------------------------------------
function corpo(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Garante que o método HTTP é o esperado
function exigir_metodo(string $metodo): void {
    if ($_SERVER['REQUEST_METHOD'] !== $metodo) {
        erro("Método não permitido. Use $metodo.", 405);
    }
}

// ---------------------------------------------------------------------
// Autenticação por token
// ---------------------------------------------------------------------
// Lê o header "Authorization: Bearer <token>", valida no banco e
// devolve o usuário. Se inválido/expirado, responde 401 e encerra.
function usuario_autenticado(): array {
    $auth = '';
    // 1) getallheaders() (Apache mod_php) — pode não existir em outros SAPIs
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        $auth = $h['Authorization'] ?? $h['authorization'] ?? '';
    }
    // 2) Fallback via $_SERVER (nginx/fastcgi/CLI e Apache com rewrite)
    if ($auth === '') {
        $auth = $_SERVER['HTTP_AUTHORIZATION']
             ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
             ?? '';
    }
    if (!preg_match('/Bearer\s+([a-f0-9]{64})/i', $auth, $m)) {
        erro('Não autenticado.', 401);
    }
    $token = $m[1];

    $stmt = db()->prepare(
        'SELECT u.* FROM tokens t
         JOIN usuarios u ON u.id = t.usuario_id
         WHERE t.token = ? AND t.expira_em > NOW() AND u.ativo = 1
         LIMIT 1'
    );
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) {
        erro('Sessão expirada. Faça login novamente.', 401);
    }
    return $user;
}

// Exige que o usuário autenticado seja de um dos tipos informados
function exigir_tipo(array $user, array $tipos_permitidos): void {
    if (!in_array($user['tipo'], $tipos_permitidos, true)) {
        erro('Você não tem permissão para esta ação.', 403);
    }
}

// ---------------------------------------------------------------------
// Gera um token aleatório de 64 caracteres hex
// ---------------------------------------------------------------------
function gerar_token(): string {
    return bin2hex(random_bytes(32));
}

// Cria um token de sessão pro usuário (validade 30 dias) e devolve a string
function criar_sessao(int $usuario_id): string {
    $token = gerar_token();
    $stmt = db()->prepare(
        'INSERT INTO tokens (usuario_id, token, expira_em)
         VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))'
    );
    $stmt->execute([$usuario_id, $token]);
    return $token;
}

// ---------------------------------------------------------------------
// Monta a URL pública de um arquivo de upload
// ---------------------------------------------------------------------
function url_upload(string $arquivo): string {
    $cfg = require __DIR__ . '/config.php';
    if (!empty($cfg['uploads_base_url'])) {
        return rtrim($cfg['uploads_base_url'], '/') . '/' . $arquivo;
    }
    // Detecta a base automaticamente a partir do request atual
    $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // .../backend-api/aluno/upload_foto.php  ->  .../backend-api
    $dir   = dirname(dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    return "$proto://$host" . rtrim($dir, '/') . "/uploads/$arquivo";
}

// Formata um registro de usuário pro formato que o app espera
function usuario_publico(array $u): array {
    // Idade calculada a partir da data de nascimento (se houver)
    $idade = null;
    if (!empty($u['data_nascimento'])) {
        try {
            $nasc = new DateTime($u['data_nascimento']);
            $idade = (new DateTime())->diff($nasc)->y;
        } catch (Throwable $e) { $idade = null; }
    }
    return [
        'id'    => (int) $u['id'],
        'nome'  => $u['nome'],
        'email' => $u['email'],
        'tipo'  => $u['tipo'],
        'classe'=> $u['classe_ativa'],
        'dataNascimento' => $u['data_nascimento'] ?? null,
        'idade' => $idade,
        'fotoUrl' => $u['foto_url'],
        'senhaProvisoria' => (bool) $u['senha_provisoria'],
        'termosAceitos'   => $u['termos_aceitos_em'] !== null,
    ];
}
