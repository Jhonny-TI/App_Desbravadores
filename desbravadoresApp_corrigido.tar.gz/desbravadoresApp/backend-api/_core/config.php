<?php
// =====================================================================
// CONFIGURAÇÃO DO BANCO — único lugar pra mexer nas credenciais
// =====================================================================
// No XAMPP padrão: host=localhost, user=root, senha vazia.
// Em produção, troque por usuário/senha reais e NUNCA suba este arquivo
// com credenciais reais pro Git (use .gitignore).

return [
    'host'    => '127.0.0.1',
    'porta'   => '3306',
    'banco'   => 'desbravadores_db',
    'usuario' => 'root',
    'senha'   => '',           // XAMPP normalmente vem sem senha no root
    'charset' => 'utf8mb4',

    // URL base pública da pasta de uploads (pra montar a URL das fotos).
    // Ex.: se o backend está em http://192.168.0.10/backend-api,
    // as fotos ficam em http://192.168.0.10/backend-api/uploads/...
    // Deixe '' que o código detecta sozinho a partir do request.
    'uploads_base_url' => '',
];
