// =============================================
// TEMA CENTRAL — paleta extraída de RequisitoScreen
// =============================================
// Para mudar a identidade visual do app inteiro, mexe aqui.

export const colors = {
  // Fundo da tela (navy escuro)
  bg: '#0f172a',
  // Fundo de cards / inputs em destaque
  card: '#1e293b',
  // Fundo de elementos "afundados" dentro de cards (ex.: barra de progresso)
  cardSunk: '#334155',
  // Cor de acento (amarelo) — botões primários, títulos, bordas laterais
  accent: '#facc15',
  // Texto que vai EM CIMA do acento amarelo
  onAccent: '#0f172a',
  // Texto branco padrão sobre fundo escuro
  text: '#ffffff',
  // Texto secundário/muted
  textMuted: '#94a3b8',
  // Borda/divisor sutil
  border: '#334155',
  // Placeholder de input
  placeholder: '#64748b',
  // Status
  success: '#22c55e',
  danger: '#ef4444',
};

export const radii = {
  sm: 8,
  md: 12,
  lg: 15,
  pill: 999,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
};

// Estilos reutilizáveis (padrões que se repetem em várias telas)
export const common = {
  // Card padrão (igual ao .cardReq do RequisitoScreen)
  card: {
    backgroundColor: colors.card,
    borderRadius: radii.lg,
    padding: spacing.lg,
  },
  // Botão primário amarelo (igual ao .btnExport)
  buttonPrimary: {
    backgroundColor: colors.accent,
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: radii.md,
    alignItems: 'center' as const,
  },
  buttonPrimaryText: {
    color: colors.onAccent,
    fontWeight: 'bold' as const,
    fontSize: 16,
  },
  // Input dentro de card escuro
  input: {
    backgroundColor: colors.bg,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radii.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 14,
    fontSize: 15,
  },
  // Título de tela (amarelo, centralizado)
  screenTitle: {
    fontSize: 24,
    color: colors.accent,
    fontWeight: 'bold' as const,
    textAlign: 'center' as const,
    marginBottom: spacing.lg,
  },
};
