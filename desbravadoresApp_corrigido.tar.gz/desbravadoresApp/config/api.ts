// =============================================
// CONFIGURAÇÃO CENTRAL DA API
// =============================================
// Desenvolvimento local (XAMPP): troque pelo IP da sua máquina
// Para descobrir seu IP local, rode: hostname -I
// Exemplo: export const API_BASE_URL = 'http://192.168.1.100/backend-api';

// Produção (servidor online): descomente a linha abaixo
// export const API_BASE_URL = 'https://seudominio.com/backend-api';

export const API_BASE_URL = 'http://localhost/backend-api';
