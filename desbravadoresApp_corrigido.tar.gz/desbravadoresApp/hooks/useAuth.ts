// =============================================
// HOOK useAuth — expõe o usuário logado pra qualquer tela
// =============================================
// Lê o usuário do AsyncStorage (via services/auth) e o devolve.
// Usa useFocusEffect pra re-ler sempre que a tela ganha foco —
// assim, depois que LoginScreen salva e volta pra Home, a Home
// percebe que o usuário entrou e atualiza o header sozinha.

import { useCallback, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { getUser, User } from '../services/auth';

export function useAuth() {
  const [user, setUserState] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const u = await getUser();
    setUserState(u);
    setLoading(false);
  }, []);

  // Roda quando a tela entra em foco (inclusive na primeira montagem)
  useFocusEffect(
    useCallback(() => {
      refresh();
    }, [refresh])
  );

  return { user, loading, refresh };
}
